<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FAQ</title>
    <style>
        @import url("https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&display=swap");

        * {
            margin: 0px;
            padding: 0px;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;

        }

        body {
            overflow-x: hidden;
            /* Prevent scrolling on width side */
            background: url(https://img.freepik.com/free-vector/abstract-blue-light-pipe-speed-zoom-black-background-technology_1142-9120.jpg);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background-size: cover;
            background-position: center;
            transition: .3s ease;
            pointer-events: auto;
            color: aliceblue;
        }

        .container {
            max-width: 600px;
            margin: 20px;
            padding: 15px;
        }


        h1 {
            text-align: center;
            margin-bottom: 20px;
            color: #6a77e7;
        }

        .faq-question {
            margin-bottom: 20px;
        }

        .faq-question p {
            font-weight: bold;
            margin-bottom: 5px;
            color: gray;
        }

        .faq-answer p {
            margin-bottom: 10px;
            display: none;
            /* Hide the answer by default */
            color: white;
        }

        .faq-answer.show p {
            display: block;
            /* Show the answer when the show class is added */
        }

        .Answer-btn {
            cursor: pointer;
            color: #6a77e7;
            margin-bottom: 10px;
        }
    </style>
</head>

<body>

    <?php
    include('header.php');
    ?>

    <div class="container">
        <h1>Frequently Asked Questions (FAQ)</h1>
        <div class="faq-question">
            <p>1. How do I register for an account?</p>
            <div class="faq-answer">
                <p>To register for an account, click on the "Register" button on the login page and fill out the required information.</p>
            </div>
            <div class="Answer-btn">Answer</div>
        </div>
        <div class="faq-question">
            <p>2. Can I take quizzes without registering?</p>
            <div class="faq-answer">
                <p>No, you need to register for an account to take quizzes and track your progress.</p>
            </div>
            <div class="Answer-btn">Answer</div>
        </div>
        <div class="faq-question">
            <p>3. How can I reset my password?</p>
            <div class="faq-answer">
                <p>You can reset your password by insert you new password on the "New Password" form on the profile page and following the instructions.</p>
            </div>
            <div class="Answer-btn">Answer</div>
        </div>
        <div class="faq-question">
            <p>4. How do I access past year papers?</p>
            <div class="faq-answer">
                <p>You can access past year papers by navigating to the "Past Year Papers" section on the homepage and selecting the desired faculty and subject.</p>
            </div>
            <div class="Answer-btn">Answer</div>
        </div>
        <div class="faq-question">
            <p>5. Can I download past year papers for offline use?</p>
            <div class="faq-answer">
                <p>Yes, you can download past year papers for offline use by clicking on the download link provided to each paper.</p>
            </div>
            <div class="Answer-btn">Answer</div>
        </div>
        <div class="faq-question">
            <p>6. How do I answer quizzes on the platform?</p>
            <div class="faq-answer">
                <p>To answer quizzes, log in to your account, navigate to the "Quizzes" section, select the quiz you want to attempt, and follow the on-screen instructions.</p>
            </div>
            <div class="Answer-btn">Answer</div>
        </div>
        <div class="faq-question">
            <p>7. Where can I find the user manual for this platform?</p>
            <div class="faq-answer">
                <p>You can find the user manual for this platform by clicking the link below:
                <a href="Code%20Mind%20Quiz%20Hub%20User%20Manual.pdf" target="_blank">User Manual</a></p>
            </div>
            <div class="Answer-btn">Answer</div>
        </div>

    </div>


    <?php
    include('ufooter.php');
    ?>

    <script>
        // JavaScript code to handle Answer button click
        document.addEventListener('DOMContentLoaded', function() {
            const AnswerBtns = document.querySelectorAll('.Answer-btn');

            AnswerBtns.forEach(btn => {
                btn.addEventListener('click', function() {
                    const answer = this.parentElement.querySelector('.faq-answer');
                    answer.classList.toggle('show');
                    this.textContent = answer.classList.contains('show') ? 'Answer' : 'Expand';
                });
            });
        });
    </script>

</body>

</html>