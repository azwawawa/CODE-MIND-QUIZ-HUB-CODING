<?php
session_start(); // Start the session

include('C:\xampp\htdocs\FYP QUIZ WEBSITE\admin\database\quizdbconfig.php'); // Include your database connection file

if (!isset($_SESSION['current_question'])) {
    $_SESSION['current_question'] = 0; // Set it to 0 for the first question
}

$quizId = 26; // Assuming a fixed quiz ID for demonstration

$sql_total_questions = "SELECT COUNT(*) AS total_questions FROM questions WHERE quiz_id = ?";
$stmt_total_questions = $conn->prepare($sql_total_questions);
$stmt_total_questions->bind_param("i", $quizId);
$stmt_total_questions->execute();
$result_total_questions = $stmt_total_questions->get_result();
$totalQuestions = $result_total_questions->num_rows > 0 ? $result_total_questions->fetch_assoc()['total_questions'] : 0;

// Fetching the current question details
$sql = "SELECT question_id, question, option1, option2, option3, option4, correct_answer FROM questions WHERE quiz_id = ? LIMIT ?, 1";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $quizId, $_SESSION['current_question']);
$stmt->execute();
$questionData = $stmt->get_result()->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['selected_option'])) {
    $selectedOption = $_POST['selected_option'];
    $correctAnswer = $questionData['correct_answer'];
    $marks = ($selectedOption == $correctAnswer) ? 2 : 0;



    // Inserting answer details into user_answers
    $sql_insert_answer = "INSERT INTO user_answers (quiz_id, question_id, selected_option, correct_answer, marks) VALUES (?, ?, ?, ?, ?)";
    $stmt_insert_answer = $conn->prepare($sql_insert_answer);

    if ($stmt_insert_answer) {
        $stmt_insert_answer->bind_param("iissi", $quizId, $questionData['question_id'], $selectedOption, $correctAnswer, $marks);
        if ($stmt_insert_answer->execute()) {
            // Increment the current question counter
            $_SESSION['current_question']++;

            // Check if all questions have been answered
            if ($_SESSION['current_question'] >= $totalQuestions) {
                header("Location: submit_quiz.php?quiz_id=$quizId"); // Redirect to a submit page
                exit();
            } else {
                header("Location: introduction_to_databases.php"); // Load the next question
                exit();
            }
        } else {
            echo "Error: Unable to execute SQL statement.";
        }
    } else {
        // Handle SQL statement preparation error
        echo "Error: SQL statement preparation failed.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz Name</title>
    <link rel="stylesheet" href="questionstyle.css">
</head>

<body>

    <div class="quiz-container">
        <h2 class="title">INTRODUCTION TO DATABASE</h2>
        <?php if (isset($questionData)) : ?>
            <div class="question-container">
                <p class="question-count">Question <?php echo $_SESSION['current_question'] + 1; ?> out of <?php echo $totalQuestions; ?>:</p>
                <p><strong><?php echo htmlspecialchars($questionData['question']); ?></strong></p>

                <form action="" method="post" id="quizForm">
                    <input type="hidden" name="quiz_id" value="<?php echo htmlspecialchars($quizId); ?>">
                    <!-- Removed the hidden correct_answer input as it's not needed in the form -->
                    <div class="option-container">
                        <label><input type="radio" name="selected_option" value="option1"> <?php echo htmlspecialchars($questionData['option1']); ?></label><br>
                        <label><input type="radio" name="selected_option" value="option2"> <?php echo htmlspecialchars($questionData['option2']); ?></label><br>
                        <label><input type="radio" name="selected_option" value="option3"> <?php echo htmlspecialchars($questionData['option3']); ?></label><br>
                        <label><input type="radio" name="selected_option" value="option4"> <?php echo htmlspecialchars($questionData['option4']); ?></label><br>
                    </div>
                    <button type="button" onclick="window.history.back();" class="back-btn">Back</button>
                    <button type="submit" class="submit-btn" id="submitBtn">Next Question</button>
                </form>

            </div>
        <?php endif; ?>
    </div>

    <div class="notification-container">
        <p id="notification-message"></p>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const optionButtons = document.querySelectorAll('input[type="radio"]');
            const selectedOptionInput = document.getElementById('selectedOption');

            optionButtons.forEach(button => {
                button.addEventListener('change', () => {
                    const selectedOption = document.querySelector('input[type="radio"]:checked').value;
                    selectedOptionInput.value = selectedOption;
                });
            });
        });
    </script>

</body>

</html>