<?php
include('C:\xampp\htdocs\FYP QUIZ WEBSITE\admin\database\quizdbconfig.php');

// Initialize the error variable
$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $username = $_POST['username'];
    $password = $_POST['password'];
    $email = $_POST['email'];

    // Database connection
    $conn = mysqli_connect("localhost","root","","admin_quiz");


    if($conn->connect_error){
        die("Connection failed: ". $conn->connect_error);
    }

    // Check if the username already exists
    $check_username_query = "SELECT * FROM user_login WHERE username='$username'";
    $result_username = $conn->query($check_username_query);
    if ($result_username->num_rows > 0) {
        $error = "Username already exists";
    } else {
        // Insert new user data into the database
        $insert_query = "INSERT INTO user_login (username, password, email) VALUES ('$username', '$password', '$email')";
        if ($conn->query($insert_query) === TRUE) {
            header("Location: login.php"); // Redirect to login page after successful registration
            exit();
        } else {
            $error = "Error registering user: " . $conn->error;
        }
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Registration</title>
    <link rel="stylesheet" href="register.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <style>
        /* Your CSS styles here */
    </style>
    <div class="container">
        <div class="form-container">
            <form action="register.php" method="POST">
                <h2>User Registration</h2>
                <div class="input-group">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" required>
                </div>
                <div class="input-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required>
                </div>
                <div class="input-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" required>
                </div>
                <button type="submit">Register</button>
                <p class="error-message"><?php echo $error; ?></p>
            </form>
            <p>Already have an account? <a href="login.php">Login here</a></p>
        </div>
    </div>
</body>
</html>
