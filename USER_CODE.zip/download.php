<?php
// Validate and sanitize the file name parameter
if (isset($_GET['file_path'])) {
    // Include your database connection and other necessary files
    include 'C:\xampp\htdocs\FYP QUIZ WEBSITE\admin\database\paperdbconfig.php';

    $file_name = basename($_GET['file_path']);

    // Define the path to the file download directory (adjust this path based on your configuration)
    $downloadDirectory = '/path/to/your/uploads/directory/';

    // Create the full path to the file
    $filePath = $downloadDirectory . $file_name;

    // Check if the file exists and is within the allowed directory
    if (file_exists($filePath) && strpos($filePath, $downloadDirectory) === 0) {
        // Set headers to open the file in the browser if supported
        header('Content-Description: File Transfer');
        header('Content-Type: ' . mime_content_type($filePath));
        header('Content-Disposition: inline; filename="' . basename($filePath) . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($filePath));
        flush(); // Flush system output buffer
        readfile($filePath);
        exit;
    } else {
        // File not found or outside allowed directory
        die('File not found or access denied.');
    }
}

?>
