<?php
session_start(); // Start the session

// Initialize the username variable
$username = "";

// Check if the user is logged in
if (isset($_SESSION['username'])) {
   
    // Create a database connection
    $host = "localhost";
    $dbusername = "root";
    $dbpassword = "";
    $dbname ="admin_quiz";
    $conn = mysqli_connect($host, $dbusername, $dbpassword, $dbname);

    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Retrieve user details from the database based on username
    $username = $_SESSION['username'];
    $query = "SELECT * FROM user_login WHERE username='$username'";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) == 1) {
       // Fetch the user details
       $row = mysqli_fetch_assoc($result);
       $username = $row['username'];
    } else {
       die("Query failed: " . mysqli_error($conn));
    }
    
    mysqli_close($conn); // Close database connection
}
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Header</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <style>
        .header {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            padding: 20px 10%;
            background: transparent;
            display: flex;
            justify-content: space-between;
            align-items: center;
            z-index: 100;

        }

        .logo {
            font-size: 30px;
            color: white;
            text-decoration: none;
            font-weight: 700;
            filter: drop-shadow(0 0 5px #09001d);
        }

        .navbar {
            display: flex;
            align-items: center;
        }

        .navbar a {
            font-size: 18px;
            color: whitesmoke;
            text-decoration: none;
            font-weight: 500;
            margin-left: 20px;
            transition: .3s;
        }

        .navbar a:hover {
            color: #6a77e7;
            text-decoration: underline;
        }


        .dropdown {
            position: relative;
        }

        .profile-container {
            display: flex;
            align-items: center;
        }

        .profile-btn {
            background: none;
            border: none;
            color: #f9f4f4;
            cursor: pointer;
            display: flex;
            align-items: center;
            margin-right: 30px;
            padding: 30px;
        }

        .username {
            color: #fff;
            font-size: 16px;
            font-weight: 500;
            margin-right: 15px;
            margin-left: 10px;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: black;
            border: 1px solid #ccc;
            border-radius: 5px;
            padding: 10px;
            z-index: 1;
            min-width: 200px;
        }

        .dropdown-content a {
            display: block;
            color: whitesmoke;
            text-decoration: none;
            padding: 8px 12px;
        }

        .dropdown-content a:hover {
            background-color: aliceblue;
        }

        .dropdown:hover .dropdown-content {
            display: block;
        }
    </style>
</head>

<body>
<header class="header">
        <a href="homepage.php" class="logo">Code Mind <br> Quiz Hub</a>
        <nav class="navbar">
            <a href="quiz.php" class="active">Quiz</a>
            <a href="Aboutpage.php">About</a>
            <a href="pastyear.php">Past Year Paper</a>
            <div class="profile-container">
                <div class="dropdown">
                    <button class="profile-btn">
                        <i class="fas fa-user"></i>
                        <?php if(isset($_SESSION['username'])) { ?> <!-- Added opening curly brace -->
                            <span class="username"><?php echo $username; ?></span> <!-- Display the username -->
                            <i class="fas fa-caret-down"></i>
                        <?php } ?>
                    </button>
                    <div class="dropdown-content">
                        <a href="profile.php"><i class="fas fa-user"></i> Profile</a>
                        <a href="marks.php"><i class="fas fa-graduation-cap"></i> Marks</a>
                        <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                    </div>
                </div>
            </div>
        </nav>
    </header>

    <script>
        // JavaScript for dropdown functionality
        document.addEventListener("DOMContentLoaded", function() {
            var profileBtn = document.querySelector(".profile-btn");
            var dropdownContent = document.querySelector(".dropdown-content");

            profileBtn.addEventListener("click", function() {
                dropdownContent.classList.toggle("show");
            });

            window.addEventListener("click", function(event) {
                if (!event.target.matches(".profile-btn")) {
                    dropdownContent.classList.remove("show");
                }
            });
        });
    </script>

</body>

</html>