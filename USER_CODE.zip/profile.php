<?php
session_start(); // Start the session

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    // Redirect to login page if not logged in
    header("Location: login.php");
    exit(); // Stop further execution
}

// Check if success message is set and display it
if (isset($_SESSION['success_message'])) {
    echo "<p style='color: green;'>{$_SESSION['success_message']}</p>";
    unset($_SESSION['success_message']); // Remove the success message after displaying it
}

// Database connection using included config file
include 'C:\xampp\htdocs\FYP QUIZ WEBSITE\admin\database\quizdbconfig.php';

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = $_SESSION['username'];
$query = "SELECT * FROM user_login WHERE username=?";
$stmt = $conn->prepare($query);

if ($stmt) {
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $password = 'Hidden'; // Don't display password directly
        $email = $row['email'];
    } else {
        // Handle database query errors
        echo "Error fetching user details.";
    }

    $stmt->close();
} else {
    // Handle database connection errors
    echo "Error preparing statement.";
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>User Profile</title>
    <style>
        @import url("https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&display=swap");

        body {
            font-family: 'Poppins', sans-serif;


            background: url(https://img.freepik.com/free-vector/abstract-blue-light-pipe-speed-zoom-black-background-technology_1142-9120.jpg);
            min-height: 100vh;
            background-size: cover;
        }

        .container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            background-color: #fff;
            /* White background color */
        }

        /* Style for h1 */
        h1 {
            color: white;
            /* Text color */
            font-size: 32px;
            /* Font size */
            margin-bottom: 20px;
            /* Bottom margin */
            text-align: center;
            /* Center align text */
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            font-weight: bold;
            display: block;
            margin-bottom: 5px;
        }

        .form-group input {
            width: calc(100% - 16px);
            /* Adjust for input padding and border */
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .form-group button {
            padding: 8px 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            /* Smooth hover effect */
        }

        .form-group button:hover {
            background-color: #0056b3;
        }

        .form-group .edit-link {
            color: #007bff;
            cursor: pointer;
            text-decoration: underline;
            transition: color 0.3s ease;
            /* Smooth hover effect */
        }

        .form-group .edit-link:hover {
            color: #0056b3;
        }

        .profile-info {
            border-bottom: 1px solid #ccc;
            /* Add border between profile info and edit form */
            margin-bottom: 20px;
            /* Add some space after the border */
            padding-bottom: 20px;
            /* Add padding after the border */
        }

        .logout-btn {
            padding: 8px 20px;
            background-color: #dc3545;
            /* Red color for logout button */
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            /* Smooth hover effect */
        }

        .logout-btn:hover {
            background-color: #c82333;
            /* Darker red on hover */
        }

        .logout-link {
            display: inline-block;
            padding: 8px 20px;
            background-color: #dc3545;
            /* Red color for logout link */
            color: #fff;
            text-decoration: none;
            /* Remove underline */
            border-radius: 4px;
            transition: background-color 0.3s ease;
            /* Smooth hover effect */
        }

        .edit-profile-form {
            padding: 20px;
            /* Add padding to the entire edit profile form */
        }

        .edit-profile-form label,
        .edit-profile-form input {
            margin-bottom: 10px;
            /* Add margin between label-input pairs */
        }

        .back-btn {
            display: inline-block;
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.3s ease;
            margin-top: 20px;
        }

        .back-btn:hover {
            background-color: #0056b3;
        }

         /* Notice message style */
         .hidden-password {
            color: #666;
            font-size: 14px;
            margin-top: 5px;
        }

        /* Show password button style */
        .show-password-btn {
            padding: 5px 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .show-password-btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>

<body>
    <header>
        <h1>Welcome to Your Profile</h1>
    </header>

    <div class="container">
    <div class="profile-info">
    <h2>User Profile</h2>
    <p><strong>Username:</strong> <?php echo $_SESSION['username']; ?></p>
    <span id="hidden-password"><?php echo isset($password) ? 'Password is hidden' : ''; ?></span>
    <p><strong>Email:</strong> <?php echo isset($email) ? $email : 'N/A'; ?></p>
</div>


        <div class="edit-profile-form">
            <h2>Edit Profile</h2>
            <form action="edit_profile.php" method="POST">
                <label for="new_username">New Username:</label>
                <input type="text" id="new_username" name="new_username" required><br>

                <label for="new_password">New Password:</label>
                <input type="password" id="new_password" name="new_password" required><br>

                <label for="new_email">New Email:</label>
                <input type="email" id="new_email" name="new_email" required><br>

                <input type="submit" value="Update Profile">
            </form>
        </div>

        <a href="logout.php" class="logout-link">Logout</a>
         <!-- Back button to homepage -->
         <a href="homepage.php" class="back-btn">Back to Homepage</a>
    </div>
</body>

</html>
<script>
        // Function to toggle password visibility
        function togglePasswordVisibility() {
            var passwordElement = document.getElementById('hidden-password');
            var hiddenPasswordMessage = document.querySelector('.hidden-password');

            if (passwordElement.type === 'text') {
                passwordElement.type = 'password';
                hiddenPasswordMessage.style.display = 'inline';
            } else {
                passwordElement.type = 'text';
                hiddenPasswordMessage.style.display = 'none';
            }
        }
    </script>