<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Privacy Policy</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="privacy.css">
</head>

<body>

    <?php
    include('header.php');
    ?>

    <div class="container">
        <div class="privacy-content">
            <h1>Privacy Policy</h1>
            <p> AT CODE MIND QUIZ HUB, your privacy matters.</p>
            <p>This Privacy Policy explains how we handle your information when you use our online quiz system at UNIVERSITY POLY-TECH MALAYSIA. We're committed to being transparent about what data we collect, why we collect it, and how we use it. This policy is designed to help you understand your privacy rights and choices.</p>
            <h2>Information We Collect</h2>
            <p> Personal Information: This information can identify you as an individual and may include your name, student ID number, email address, and any other information you voluntarily provide when registering or taking a quiz.</p>
            <p> Non-Personal Information: This information does not identify you as an individual and may include data about your device, operating system, browser type, IP address, and your activity within the quiz system (e.g., quiz scores, answer choices).</p>
            <h2>How We Use Your Information</h2>
            <p>We use the information we collect for the following purposes:</p>
            <ul>
                <li>To provide and administer the CODE MIND QUIZ HUB platform.</li>
                <li>To personalize your experience by tailoring quizzes and displaying relevant information.</li>
                <li>To analyze user behavior and improve the platform.</li>
                <li>To communicate with you about quizzes, announcements, and updates.</li>
                <li>To comply with legal and regulatory requirements.</li>
            </ul>
            <h2>Data Sharing and Disclosure</h2>
            <p>We will not sell or share your personal information with any third party for marketing purposes. We may disclose your information in the following circumstances:</p>
            <ul>
                <li>To service providers who help us operate the platform (e.g., data storage, analytics). These providers are bound by contractual obligations to keep your information confidential.</li>
                <li>To comply with a court order, legal process, or other legal requirement.</li>
                <li>To investigate potential violations of our policies or illegal activity.</li>
            </ul>
            <h2>Your Rights</h2>
            <p>You have certain rights regarding your personal information:</p>
            <ul>
                <li>Access: You have the right to request access to the personal information we hold about you.</li>
                <li>Correction: You have the right to request that we correct any inaccurate information about you.</li>
                <li>Erasure: You have the right to request that we erase your personal information, subject to certain exceptions.</li>
                <li>Restriction: You have the right to restrict how we process your personal information.</li>
                <li>Objection: You have the right to object to how we process your personal information, such as for direct marketing purposes.</li>
            </ul>
            <h2>Data Retention</h2>
            <p>We will retain your personal information for as long as your account is active or as needed to provide you with the services. We may also retain your information for a longer period as required by law or to comply with regulatory requirements.</p>
            <h2>Children's Privacy</h2>
            <p>CODE MIND QUIZ HUB is not intended for children under the age of 13. We do not knowingly collect personal information from children under 13. If you are a parent or guardian and you believe your child has provided us with personal information, please contact us. We will take steps to remove the information from our systems.</p>
            <h2>Security</h2>
            <p>We take reasonable steps to protect your personal information from unauthorized access, disclosure, alteration, or destruction. However, no internet or electronic storage system is 100% secure.</p>
            <h2>Changes to this Privacy Policy</h2>
            <p>We may update this Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page.</p>
            <h2>Contact Us</h2>
            <p>If you have any questions about this Privacy Policy, please contact us at <a href="contact.php" class="contact-link">Contact</a>.</p>
            <p>For frequently asked questions, please visit our <a href="faq.php" class="contact-link">FAQ </a>.</p>

            <?php
            include('ufooter.php');
            ?>

        </div>

    </div>



</body>

</html>