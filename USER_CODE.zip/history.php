<?php
// Create a database connection
$host = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname ="admin_quiz";
$conn = mysqli_connect($host, $dbusername, $dbpassword, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Fetch quiz history from the database using prepared statement
$sql = "SELECT * FROM quiz_history ORDER BY timestamp DESC";
$stmt = mysqli_prepare($conn, $sql);
if ($stmt === false) {
    die("Error in prepared statement: " . mysqli_error($conn));
}
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

// Close the statement and database connection
mysqli_stmt_close($stmt);
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz History</title>
    <!-- Import Google Fonts and Font Awesome -->
    <style>
        @import url("https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&display=swap");
        @import url("https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css");

        * {
            margin: 0px;
            padding: 0px;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: url(https://img.freepik.com/free-vector/abstract-blue-light-pipe-speed-zoom-black-background-technology_1142-9120.jpg);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background-size: cover;
            background-position: center;
            transition: .3s ease;
            pointer-events: auto;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        .table-container {
            margin-top: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: center;
        }

        th {
            background-color: #333;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #ddd;
        }

        .homepage-btn {
            margin-top: 20px;
            text-align: center;
        }

        .homepage-btn a {
            color: white;
            background-color: #333;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .homepage-btn a:hover {
            background-color: #555;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1 style="text-align: center; color: white;">Quiz History</h1>
        <div class="table-container">
            <table>
                <tr>
                    <th>User</th>
                    <th>Quiz Name</th>
                    <th>Action</th>
                    <th>Timestamp</th>
                </tr>
                <?php
                // Display the history entries in a table
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td>{$row['user_id']}</td>";
                    echo "<td>{$row['quiz_name']}</td>";
                    echo "<td>{$row['action']}</td>";
                    echo "<td>{$row['timestamp']}</td>";
                    echo "</tr>";
                }
                ?>
            </table>
        </div>
        <div class="homepage-btn">
            <a href="homepage.php">Go to Homepage</a>
        </div>
    </div>
</body>

</html>