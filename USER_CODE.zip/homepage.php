<?php
include ('header.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X_UA_Compatible" content="IE-edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="homestyle.css">
    <title>Home</title>
</head>
<body>
<main class="main">
    <div class="container">
        <section class="home">
            <div class="home-content">
                <h1>WELCOME</h1>
                <p>Challenge yourself and test your knowledge with our engaging quizzes!</p>
                <p>Calling all CC101 students!  Ready to put your skills to the test? This online quiz system is your one-stop shop for fun quizzes and past year papers. Play, learn, and conquer your exams!</p>
                <button class="start-btn">Start Quiz</button>
            </div>
        </section>
    </div>
    <div id="popupInfo" class="popup-info">
        <h2>Quiz Guide</h2>
        <span class="info">1. Read each question carefully before answering.</span> <br>
        <span class="info">2. You can skip questions and come back to them later.</span> <br>
        <span class="info">3. Don't forget to submit your answers !</span>
        <div class="btn-group">
            <button class="info-btn exit-btn">Exit Quiz</button>
            <button class="info-btn continue-btn">Continue Quiz</button>
        </div>
    </div>

   
</main>
<?php
include ('ufooter.php');
?> 
<script src="script.js"></script>
</body>
</html>
