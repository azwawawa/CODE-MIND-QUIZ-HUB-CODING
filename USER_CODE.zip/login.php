<?php
session_start(); // Start the session

// Initialize $error variable
$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Database connection using included config file
    $host = "localhost";
    $dbusername = "root";
    $dbpassword = "";
    $dbname = "admin_quiz";
    $conn = mysqli_connect("localhost", "root", "", "admin_quiz");

    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Validate login authentication
    $query = "SELECT * FROM user_login WHERE username='$username' AND password= '$password'";
    $result = mysqli_query($conn, $query);

    if (!$result) {
        die("Query failed: " . mysqli_error($conn));
    }

    if (mysqli_num_rows($result) == 1) {
        // User found, set session variable and redirect to homepage
        $_SESSION['username'] = $username; // Set session variable for logged-in user
        header("Location: homepage.php");
        exit();
    } else {
        $error = "Invalid username or password";
    }

    
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Login</title>
    <link rel="stylesheet" href="login.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>

<body>
    <div class="header">
        <h1>CODE MIND QUIZ HUB</h1>
    </div>
    <div class="container">
        <div class="form-container">
            <form action="" method="POST">
                <h2>User Login</h2>
                <div class="input-group">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" value="<?php echo isset($username) ? $username : ''; ?>" required>
                </div>
                <div class="input-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required>
                </div>
                <button type="submit">Login</button>
                <p class="error-message"><?php echo $error; ?></p>
            </form>
            <p>Don't have an account? <a href="register.php">Register here</a></p>
        </div>
    </div>
</body>

</html>