<?php
// Include necessary files like header, database connection, etc.
include('header.php');

$servername = "localhost";
$username = "root"; // Replace 'your_username' with your actual database username
$password = ""; // Replace 'your_password' with your actual database password
$dbname = "admin_quiz"; // Replace 'your_database_name' with your actual database name

// Create connection
$conn= mysqli_connect('localhost','root','','admin_quiz');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if a quiz ID is provided in the URL
if(isset($_GET['quiz_id'])) {
    $quiz_id = $_GET['quiz_id'];

    // Query to fetch quiz questions from the database based on quiz_id
    // Replace 'questions' with your actual table name for quiz questions
    $query = "SELECT * FROM questions WHERE quiz_id = $quiz_id";
    $result = mysqli_query($conn, $query);

    // Display quiz questions
    if(mysqli_num_rows($result) > 0) {
        // Loop through the questions and display them
        while($row = mysqli_fetch_assoc($result)) {
            echo "<h2>{$row['question']}</h2>";
            // Display options or any other question details
        }
    } else {
        echo "No questions found for this quiz.";
    }

    // Add form and submit button for answering questions, etc.
} else {
    echo "Quiz ID not provided.";
}

// Include footer or any other necessary files
include('ufooter.php');
?>
