<?php
// Include your database connection and other necessary files
include 'C:\xampp\htdocs\FYP QUIZ WEBSITE\admin\database\paperdbconfig.php';

// Initialize variables
$error = "";
$success = false;
$faculty = "";
$subject = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate and sanitize input
    $faculty = mysqli_real_escape_string($conn, $_POST['faculty']);
    $subject = mysqli_real_escape_string($conn, $_POST['subject']);

    // Check if either faculty or subject is provided
    if (!empty($faculty) || !empty($subject)) {
        // Construct the WHERE clause based on input
        $whereClause = "";
        if (!empty($faculty)) {
            $whereClause = " WHERE faculty = '$faculty'";
        }
        if (!empty($subject)) {
            if (!empty($whereClause)) {
                $whereClause .= " AND subject = '$subject'";
            } else {
                $whereClause = " WHERE subject = '$subject'";
            }
        }

        // Fetch papers based on the constructed query
        $sql_search_papers = "SELECT * FROM pastpaper" . $whereClause;
        $result_search_papers = mysqli_query($conn, $sql_search_papers);

        if (!$result_search_papers) {
            die("Error fetching papers: " . mysqli_error($conn));
        }

        if (mysqli_num_rows($result_search_papers) > 0) {
            $success = true; // Papers found
        } else {
            $error = "No papers found for the provided keywords.";
        }
    } else {
        $error = "Please enter either faculty or subject.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Paper</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&display=swap">
    <link rel="stylesheet" href="viewpaper.css">
</head>

<body>
    <?php include('header.php'); ?>

    <h1>PAST YEAR PAPER</h1>

    <!-- Search form for additional functionality -->
    <form action="view_paper.php" method="POST" class="search-form">
        <!-- Input fields for faculty and subject -->
        <input type="text" name="faculty" placeholder="Faculty" value="<?= htmlspecialchars($faculty); ?>">
        <input type="text" name="subject" placeholder="Subject" value="<?= htmlspecialchars($subject); ?>">
        <button type="submit" class="search-btn">Search</button>
        
    </form>

    <?php if ($error) : ?>
        <div class="error-message" style="margin-left: 30px; margin-bottom: 10px; text-align: center; color: #dc3545;"><?= $error; ?></div>
    <?php elseif ($success) : ?>
        <div class="container">
            <div class="success-message" style="margin-left: 30px; margin-bottom: 10px; text-align: center; color: #28a745;">Papers found for the provided keywords.</div>
            <ul class="paper-list">
                <?php while ($row = mysqli_fetch_assoc($result_search_papers)) : ?>
                    <li class="paper-item">
                        <h2><?= htmlspecialchars($row['paper_title']); ?></h2>
                        <p><?= htmlspecialchars($row['paper_description']); ?></p>
                        <!-- Display download and view buttons with appropriate links -->
                        <?php if (!empty($row['file_path'])) : ?>
                            <?php
                            $file_path = $row['file_path']; // Assuming file_path contains the full path to the file
                            $file_name = basename($file_path);
                            $download_link = "download.php?file=" . urlencode($file_path); // Use the full file path in the download link
                            ?>
                            <a href="<?= $download_link ?>" download="<?= $file_name ?>">
                                <i class="fas fa-download"></i> Download
                            </a>

                            <!-- View button for directly viewing the file -->
                            <a href="<?= $file_path ?>" target="_blank">
                                <i class="fas fa-eye"></i> View File
                            </a>
                        <?php else : ?>
                            No file
                        <?php endif; ?>



                    </li>
                <?php endwhile; ?>



            </ul>
        </div>
    <?php endif; ?>

</body>

</html>