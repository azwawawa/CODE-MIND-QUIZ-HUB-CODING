<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>
    <link rel="stylesheet" href="privacy.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&display=swap">
    <style>
        /* Add your CSS styles here */
        @import url("https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&display=swap");

        * {
            margin: 0px;
            padding: 0px;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;

        }

        body {
            overflow-x: hidden;
            /* Prevent scrolling on width side */
            background: url(https://img.freepik.com/free-vector/abstract-blue-light-pipe-speed-zoom-black-background-technology_1142-9120.jpg);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background-size: cover;
            background-position: center;
            transition: .3s ease;
            pointer-events: auto;
            color: aliceblue;
        }

        .container {
            max-width: 600px;
            margin: 20px;
            padding: 15px;
        }

        .privacy-content {
            padding: 20px;
            max-width: 600px;
            /* Limiting the width of the content */
            margin: 0 auto;
            /* Centering the content */
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
            color: #6a77e7;
            /* Change color to a light blue */
        }

        p {
            line-height: 1.6;
            margin-bottom: 10px;
            text-align: justify;
        }
    </style>
</head>

<body>

    <?php
    include('header.php');
    ?>

    <div class="container">
        <div class="privacy-content">
            <h1>Contact Us</h1>
            <p>If you have any questions or inquiries, feel free to reach out to us using the contact details provided below:</p>
            <ul>
                <li>Email: naasyazrin18@gmail.com</li>
                <li>Phone: 01139544041</li>
                <li>Address: University Poly-Tech Malaysia. Jalan 6/91, Taman Shamelin Perkasa, 56100 Kuala Lumpur, Wilayah Persekutuan Kuala Lumpur</li>
            </ul>
            <?php
            include('ufooter.php');
            ?>

        </div>
    </div>


</body>

</html>