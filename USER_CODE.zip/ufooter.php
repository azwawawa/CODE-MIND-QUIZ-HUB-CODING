<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&display=swap">
    <title>Footer</title>
    <style>
        body {

            font-family: 'Poppins', sans-serif;
            position: relative; /* Set position to relative for footer placement */
        }
        .footer {
            background: transparent;
            color: #fff;
            padding: 1rem;
            text-align: center;
            position: absolute; /* Position the footer absolutely */
            bottom: 0; /* Position at the bottom */
            width: 100%; /* Full width */
        }

        .footer p {
            margin: 0;
        }

        .footer a {
            color: lightblue;
            text-decoration: none;
            margin: 0 5px;
        }

        .footer a:hover {
            text-decoration: underline;
            color: white;
        }
    </style>
</head>
<body>
    <footer class="footer">
        <p>&copy; 2024 <a href="homepage.php">Code Mind Quiz Hub </a> | 
        <a href="privacy.php">Privacy Policy</a> | 
        <a href="contact.php">Contact</a> |
        <a href="faq.php">FAQ</a> | 
        </p>
    </footer>
</body>
</html>
