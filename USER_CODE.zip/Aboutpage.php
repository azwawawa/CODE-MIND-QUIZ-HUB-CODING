
<?php



session_start(); // Start the session

// Initialize the username variable
$username = "";

// Check if the user is already logged in
if (isset($_SESSION['username'])) {
    // Include the database configuration file
    include('C:\xampp\htdocs\FYP QUIZ WEBSITE\admin\database\quizdbconfig.php');

    // Retrieve user details from the database based on username
    $username = $_SESSION['username'];
    $query = "SELECT * FROM user_login WHERE username='$username'";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) == 1) {
        // Fetch the user details
        $row = mysqli_fetch_assoc($result);
        $username = $row['username'];
    }

    mysqli_close($conn); // Close database connection
}



?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X_UA_Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="aboutstyle.css">
    <title>About</title>
</head>
<body>
    <main class="main">
        <section class="hero">
        <header class="header">
    <a href="homepage.php" class="logo">Code Mind <br> Quiz Hub</a>
    <nav class="navbar">
        <a href="quiz.php" class="active">Quiz</a>
        <a href="Aboutpage.php">About</a>
        <a href="pastyear.php">Past Year Paper</a>
        <div class="profile-container">
            <div class="dropdown">
                <button class="profile-btn">
                <i class="fas fa-user"></i>
                        <?php if(isset($_SESSION['username'])) { ?> <!-- Added opening curly brace -->
                            <span class="username"><?php echo $username; ?></span> <!-- Display the username -->
                            <i class="fas fa-caret-down"></i>
                        <?php } ?>
                    </button>
                    <div class="dropdown-content">
                        <a href="profile.php"><i class="fas fa-user"></i> Profile</a>
                        <a href="marks.php"><i class="fas fa-graduation-cap"></i> Marks</a>
                        <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                    </div>
            </div>
        </div>
    </nav>
</header>

            <div class="container">
                <div class="hero-image">
                    <img src="https://alkhawarizmi.uptm.edu.my/images/MAJLIS%20PEMASYHURAN%20UPTM/files/mobile-ext/appLogoIcon.png?230308180750">
                </div>
                <div class="hero-content">
                    <h2>Welcome To Our Quiz Online System</h2>
                    <p>At Quiz Online System, we aim to provide an engaging and interactive platform for learning and assessment. Our system is designed to facilitate both educators and learners in the process of knowledge acquisition and evaluation.</p>
                    <p>You're a student looking to test your understanding of various, our platform offers a wide range of features to meet your needs.</p>
                    <p>With our intuitive interface, users can easily take quizzes on a variety of topics, our system supports diverse formats to accommodate different learning objectives.</p>
                    <p>Our mission is to foster a dynamic learning environment where users can engage with course materials,and receive feedback to enhance their learning outcomes.</p>
                    <a href="https://www.uptm.edu.my/" class="cta-button">Learn More</a>

                </div>
            </div>
        </section>
    </main>
    <script>
// JavaScript for dropdown functionality
document.addEventListener("DOMContentLoaded", function() {
    var profileBtn = document.querySelector(".profile-btn");
    var dropdownContent = document.querySelector(".dropdown-content");

    profileBtn.addEventListener("click", function() {
        dropdownContent.classList.toggle("show");
    });

    window.addEventListener("click", function(event) {
        if (!event.target.matches(".profile-btn")) {
            dropdownContent.classList.remove("show");
        }
    });
});
</script>

<?php
    include('ufooter.php');
    ?>
</body>
</html>
