




<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="quizstyle.css">
    <title>Quiz</title>
</head>

<body>
    <main class="main">
        <?php include('header.php'); ?>

        <h1 class="title">Quiz</h1>
        <form action="" method="GET" id="quizForm">
    <div class="search">
        <input type="text" id="searchSemester" name="searchSemester" placeholder="Search semester..." style="width: 800px;">
        <button type="button" id="searchButton" style="width: 100px;">Search</button>
    </div>
    <span id="searchResult"></span>
</form>


            <div class="semester-selector">
                <p class="selector-label">Select Semester:</p>
                <button type="button" class="selector-item" value="semester1">Semester 1</button>
                <button type="button" class="selector-item" value="semester2">Semester 2</button>
                <button type="button" class="selector-item" value="semester3">Semester 3</button>
                <button type="button" class="selector-item" value="semester4">Semester 4</button>
                <button type="button" class="selector-item" value="semester5">Semester 5</button>
                <button type="button" class="selector-item" value="semester6">Semester 6</button>
                <button type="button" class="selector-item" value="semester7">Semester 7</button>
            </div>
            
            <div class="subject-selector" id="subjectSelector" style="display: none;">
                <button type="button" class="start-quiz-btn" id="startQuizBtn">Choose Subject</button>
            </div>
        </form>
    </main>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            var semesterButtons = document.querySelectorAll('.semester-selector button');
            var subjectSelect = document.getElementById('subjectSelector');

            // Add event listeners to semester buttons
            semesterButtons.forEach(function (button) {
                button.addEventListener('click', function () {
                    var semester = this.value;

                    // Show "Choose Subject" button for the chosen semester
                    subjectSelect.style.display = 'block';

                    // Redirect to quiz page with selected semester
                    document.getElementById('startQuizBtn').addEventListener('click', function () {
                        window.location.href = semester + '.php';
                    });
                });
            });

            // Add event listener to search button
            document.getElementById('searchButton').addEventListener('click', function () {
                var searchInput = document.getElementById('searchSemester').value.toLowerCase();

                // Loop through semester buttons to filter based on search input
                semesterButtons.forEach(function (button) {
                    var buttonText = button.textContent.toLowerCase();
                    if (buttonText.includes(searchInput)) {
                        button.style.display = 'block'; // Display button if it contains the search input
                    } else {
                        button.style.display = 'none'; // Hide button if it doesn't contain the search input
                    }
                });
            });
        });
    </script>

    <?php include('ufooter.php'); ?>
</body>

</html>
