<?php
// Include your database connection file for the admin database
include('C:\xampp\htdocs\FYP QUIZ WEBSITE\admin\database\quizdbconfig.php');

// Include header file
include('header.php');
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Semester 2 Subjects</title>
    <link rel="stylesheet" href="semester.css">
</head>

<body>
    <main class="main">
        <h1 class="title">SEMESTER 2 SUBJECTS</h1>

        <div class="table-responsive">
            <?php
            // Establish database connection
            $connection = mysqli_connect("localhost", "root", "", "admin_quiz");

            // Check connection
            if (!$connection) {
                die("Connection failed: " . mysqli_connect_error());
            }

            $semester = "Semester 2"; // Specify the semester you want to display
            $query = "SELECT * FROM quizzes WHERE semester = '$semester' ORDER BY subject";
            $query_run = mysqli_query($connection, $query);

            if ($query_run && mysqli_num_rows($query_run) > 0) {
                $current_subject = null;
                while ($row = mysqli_fetch_assoc($query_run)) {
                    if ($current_subject !== $row['subject']) {
                        // Start a new section for each subject
                        if ($current_subject !== null) {
                            echo '</tbody></table>'; // Close the previous table if it's not the first subject
                        }
                        echo '<h2 style="color: white;">' . $row['subject'] . '</h2>';

                        echo '<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>Quiz Name</th>
                                        <th>Quiz Description</th>
                                        <th>Action</th> 
                                    </tr>
                                </thead>
                                <tbody>'; // Start a new table for the subject
                        $current_subject = $row['subject'];
                    }
            ?>
                  <tr>
                    <td><?php echo $row['quiz_name']; ?></td>
                    <td><?php echo $row['quiz_description']; ?></td>
                    <td>
                        <?php
                        // Convert quiz name to a lower case string and replace spaces with underscores
                        $formattedQuizName = strtolower(str_replace(' ', '_', $row['quiz_name']));
                        // Append '.php' to form the filename
                        $quizPage = $formattedQuizName . '.php';
                        ?>

                        <form action="<?php echo htmlspecialchars($quizPage); ?>" method="GET">
                            <input type="hidden" name="quiz_id" value="<?php echo htmlspecialchars($row['quiz_id']); ?>">
                            <button type="submit" name="start_quiz_btn" class="start-quiz-btn">Start Quiz</button>
                        </form>
                    </td>
                </tr>

            <?php
                }
                echo '</tbody></table>'; // Close the last table
            } else {
                echo '<p style="color: blue;">No quizzes found for Semester 2.</p>';
            }

            // Close the database connection
            mysqli_close($connection);
            ?>
        </div>

        <h2 id="quizTitle"></h2>

        <script>
            // Function to fetch quiz name and update title
            function fetchQuizName() {
                var xhr = new XMLHttpRequest();
                xhr.open("GET", "fetch_quiz_name.php", true);
                xhr.onreadystatechange = function() {
                    if (xhr.readyState === 4 && xhr.status === 200) {
                        var response = JSON.parse(xhr.responseText);
                        document.getElementById("quizTitle").textContent = response.quizName;
                    }
                };
                xhr.send();
            }

            // Call fetchQuizName function when the page loads
            window.onload = function() {
                fetchQuizName();
            };
        </script>
    </main>

    <?php
    // Include footer file
    include('ufooter.php');

    // Insert code to log quiz history here
    if (isset($_GET['start_quiz_btn']) && isset($_GET['quiz_id'])) {
        $user_id = 1; // Assuming you have a way to get the user ID
        $quiz_id = $_GET['quiz_id']; // Get the quiz ID from the URL parameters
        $action = "started"; // Action for starting the quiz

        // Insert data into quiz_history table for starting the quiz
        $connection = mysqli_connect("localhost", "root", "", "admin_quiz");
        if (!$connection) {
            die("Connection failed: " . mysqli_connect_error());
        }

        $sql_insert = "INSERT INTO quiz_history (user_id, quiz_id, action) VALUES (?, ?, ?)";
        $stmt_insert = mysqli_prepare($connection, $sql_insert);
        if ($stmt_insert === false) {
            die("Error in prepared statement: " . mysqli_error($connection));
        }

        mysqli_stmt_bind_param($stmt_insert, "iis", $user_id, $quiz_id, $action);
        $result_insert = mysqli_stmt_execute($stmt_insert);

        if ($result_insert) {
            echo '<script>alert("Quiz history logged successfully!");</script>';
        } else {
            echo '<script>alert("Error logging quiz history: ' . mysqli_error($connection) . '");</script>';
        }

        mysqli_stmt_close($stmt_insert);
        mysqli_close($connection);
    }
    ?>
</body>

</html>
