<?php include('header.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X_UA_Compatible" content="IE-edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="pastyear.css">
    <title>Past Year Papers</title>
</head>
<body>

<main class="main">
        <section class="hero">

    <h1 class="title">Past Year Paper</h1>
    <div class="container">
    <form action="view_paper.php" method="post">
    <label for="faculty">Select Faculty:</label>
    <select name="faculty" id="faculty">
        <option value="fcom">Faculty of Computing & Multimedia</option>
        <option value="fbus">Faculty of Business, Accountancy & Social Sciences</option>
        <option value="fedu">Faculty of Education, Social Sciences & Humanities</option>
        <option value="ips">Institute of Professional Studies</option>
        <option value="igs">Institute of Graduate Studies</option>
        <option value="cigs">Centre of Islamic, General & Language Studies</option>
    </select>

<label for="subject">Subject:</label>
<select name="subject" id="subject">
    <!-- Subjects for Faculty of Computing & Multimedia -->
    <optgroup label="Faculty of Computing & Multimedia">
        <option value="compsci">Computer Science</option>
        <option value="programming">Programming</option>
        <option value="networking">Networking</option>
        <option value="database">Database Management</option>
        <option value="webdev">Web Development</option>
        <option value="graphics">Graphics Design</option>
        <option value="animation">Animation</option>
    </optgroup>
    
    <!-- Subjects for Faculty of Business, Accountancy & Social Sciences -->
    <optgroup label="Faculty of Business, Accountancy & Social Sciences">
        <option value="accounting">Accounting</option>
        <option value="economics">Economics</option>
        <option value="management">Management</option>
        <option value="marketing">Marketing</option>
    </optgroup>
    
    
    <!-- Subjects for Faculty of Education, Social Sciences & Humanities -->
    <optgroup label="Faculty of Education, Social Sciences & Humanities">
        <option value="education">Education Studies</option>
        <option value="psychology">Psychology</option>
        <option value="sociology">Sociology</option>
        <option value="history">History</option>
    </optgroup>
    
    <!-- Subjects for Institute of Professional Studies -->
    <optgroup label="Institute of Professional Studies">
        <option value="law">Law Studies</option>
        <option value="finance">Finance</option>
        <option value="hr">Human Resource Management</option>
        <option value="leadership">Leadership Studies</option>
    </optgroup>
    
    <!-- Subjects for Institute of Graduate Studies -->
    <optgroup label="Institute of Graduate Studies">
        <option value="research">Research Methodology</option>
        <option value="thesis">Thesis Writing</option>
        <option value="statistics">Statistics</option>
        <option value="ethics">Ethics in Research</option>
    </optgroup>
    
    <!-- Subjects for Centre of Islamic, General & Language Studies -->
    <optgroup label="Centre of Islamic, General & Language Studies">
        <option value="islamic">Islamic Studies</option>
        <option value="language">Language Studies</option>
        <option value="philosophy">Philosophy</option>
        <option value="culture">Cultural Studies</option>
    </optgroup>
</select>

<button type="submit">View Paper</button>
</form>
    </div>
   
        </section>
        <?php
    include('ufooter.php');
    ?>
</body>
</html>
 
<script>
    // Function to populate subjects based on the selected faculty
    function populateSubjects() {
        const faculty = document.getElementById("faculty").value;
        const subjectSelect = document.getElementById("subject");

        // Clear existing options
        subjectSelect.innerHTML = "";

        // Set subjects based on the selected faculty
        if (faculty === "fcom") {
            const compsciOption = document.createElement("option");
            compsciOption.text = "Computer Science";
            compsciOption.value = "compsci";
            subjectSelect.appendChild(compsciOption);

            const programmingOption = document.createElement("option");
            programmingOption.text = "Programming";
            programmingOption.value = "programming";
            subjectSelect.appendChild(programmingOption);

            const networkingOption = document.createElement("option");
            networkingOption.text = "Networking";
            networkingOption.value = "networking";
            subjectSelect.appendChild(networkingOption);

            const databaseOption = document.createElement("option");
            databaseOption.text = "Database Management";
            databaseOption.value = "database";
            subjectSelect.appendChild(databaseOption);

            const webdevOption = document.createElement("option");
            webdevOption.text = "Web Development";
            webdevOption.value = "webdev";
            subjectSelect.appendChild(webdevOption);

            const graphicsOption = document.createElement("option");
            graphicsOption.text = "Graphics Design";
            graphicsOption.value = "graphics";
            subjectSelect.appendChild(graphicsOption);

            const animationOption = document.createElement("option");
            animationOption.text = "Animation";
            animationOption.value = "animation";
            subjectSelect.appendChild(animationOption);
        } else if (faculty === "fbus") {
            const accountingOption = document.createElement("option");
            accountingOption.text = "Accounting";
            accountingOption.value = "accounting";
            subjectSelect.appendChild(accountingOption);

            const economicsOption = document.createElement("option");
            economicsOption.text = "Economics";
            economicsOption.value = "economics";
            subjectSelect.appendChild(economicsOption);

            const managementOption = document.createElement("option");
            managementOption.text = "Management";
            managementOption.value = "management";
            subjectSelect.appendChild(managementOption);

            const marketingOption = document.createElement("option");
            marketingOption.text = "Marketing";
            marketingOption.value = "marketing";
            subjectSelect.appendChild(marketingOption);
        }
                // Add else-if conditions and subjects for other faculties here...
                else if (faculty === "fedu") {
            const educationOption = document.createElement("option");
            educationOption.text = "Education Studies";
            educationOption.value = "education";
            subjectSelect.appendChild(educationOption);

            const psychologyOption = document.createElement("option");
            psychologyOption.text = "Psychology";
            psychologyOption.value = "psychology";
            subjectSelect.appendChild(psychologyOption);

            const sociologyOption = document.createElement("option");
            sociologyOption.text = "Sociology";
            sociologyOption.value = "sociology";
            subjectSelect.appendChild(sociologyOption);

            const historyOption = document.createElement("option");
            historyOption.text = "History";
            historyOption.value = "history";
            subjectSelect.appendChild(historyOption);
        } else if (faculty === "ips") {
            const lawOption = document.createElement("option");
            lawOption.text = "Law Studies";
            lawOption.value = "law";
            subjectSelect.appendChild(lawOption);

            const financeOption = document.createElement("option");
            financeOption.text = "Finance";
            financeOption.value = "finance";
            subjectSelect.appendChild(financeOption);

            const hrOption = document.createElement("option");
            hrOption.text = "Human Resource Management";
            hrOption.value = "hr";
            subjectSelect.appendChild(hrOption);

            const leadershipOption = document.createElement("option");
            leadershipOption.text = "Leadership Studies";
            leadershipOption.value = "leadership";
            subjectSelect.appendChild(leadershipOption);
        } else if (faculty === "igs") {
            const researchOption = document.createElement("option");
            researchOption.text = "Research Methodology";
            researchOption.value = "research";
            subjectSelect.appendChild(researchOption);

            const thesisOption = document.createElement("option");
            thesisOption.text = "Thesis Writing";
            thesisOption.value = "thesis";
            subjectSelect.appendChild(thesisOption);

            const statisticsOption = document.createElement("option");
            statisticsOption.text = "Statistics";
            statisticsOption.value = "statistics";
            subjectSelect.appendChild(statisticsOption);

            const ethicsOption = document.createElement("option");
            ethicsOption.text = "Ethics in Research";
            ethicsOption.value = "ethics";
            subjectSelect.appendChild(ethicsOption);
        } else if (faculty === "cigs") {
            const islamicOption = document.createElement("option");
            islamicOption.text = "Islamic Studies";
            islamicOption.value = "islamic";
            subjectSelect.appendChild(islamicOption);

            const languageOption = document.createElement("option");
            languageOption.text = "Language Studies";
            languageOption.value = "language";
            subjectSelect.appendChild(languageOption);

            const philosophyOption = document.createElement("option");
            philosophyOption.text = "Philosophy";
            philosophyOption.value = "philosophy";
            subjectSelect.appendChild(philosophyOption);

            const cultureOption = document.createElement("option");
            cultureOption.text = "Cultural Studies";
            cultureOption.value = "culture";
            subjectSelect.appendChild(cultureOption);
        }

        // Populate subjects initially based on the default selected faculty
        populateSubjects();
    }

    // Event listener to trigger when the faculty selection changes
    document.getElementById("faculty").addEventListener("change", populateSubjects);

    // Populate subjects initially based on the default selected faculty
    populateSubjects();
</script>

