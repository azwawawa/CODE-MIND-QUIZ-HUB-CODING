<?php
// Include your database connection file
include('C:\xampp\htdocs\FYP QUIZ WEBSITE\admin\database\quizdbconfig.php');



// Check if quiz_id parameter is set in the URL
if (isset($_GET['quiz_id'])) {
    $quizId = $_GET['quiz_id'];

    // Fetch individual marks from user_answers table for the specific quiz ID
    $sql_marks = "SELECT marks FROM user_answers WHERE quiz_id = ?";
    $stmt_marks = $conn->prepare($sql_marks);
    $stmt_marks->bind_param("i", $quizId);
    $stmt_marks->execute();
    $result_marks = $stmt_marks->get_result();

    $totalMarks = 0; // Initialize total marks to calculate the sum

    while ($row = $result_marks->fetch_assoc()) {
        $totalMarks += $row['marks']; // Summing up individual marks
    }

}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="submit_quiz.css">
    <title>Submit Quiz</title>
</head>

<body>
    <?php
    include('header.php');
    ?>
    <div class="quiz-container">
        <h1>Thank you for answering this quiz!</h1>

        <!-- Display total marks -->
        <?php
        if ($totalMarks > 0) {
            echo "<p>Total Marks: $totalMarks</p>";
        } else {
            echo "<p>Total Marks: N/A</p>";
        }
        ?>

        <a href="homepage.php" class="btn">Homepage</a>
        <!-- Button to view marks -->
        <a href="marks.php" class="btn">View Marks</a>
    </div>
</body>

</html>
