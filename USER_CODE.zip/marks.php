<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Marks</title>
    <!-- Import Google Fonts and Font Awesome -->
    <style>
        @import url("https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&display=swap");

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: url(https://img.freepik.com/free-vector/abstract-blue-light-pipe-speed-zoom-black-background-technology_1142-9120.jpg);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background-size: cover;
            background-position: center;
            transition: .3s ease;
            pointer-events: auto;
            font-family: 'Poppins', sans-serif;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        h1 {
            margin-bottom: 20px;
            text-align: center;
            color: white;
        }

        .card {
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: background-color 0.3s ease;
        }

        .quiz-name {
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 10px;
            color: #007bff; /* Blue text color */
        }

        .marks-details {
            margin-top: 10px;
        }

        .marks-details div {
            margin-bottom: 5px;
        }

        .btn {
            display: inline-block;
            padding: 10px 20px;
            background-color: #007bff; /* Blue background color */
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s ease;
            margin-top: 20px;
            font-weight: bold;
        }

        .btn:hover {
            background-color: #0056b3; /* Darker blue on hover */
        }

        /* Add hover effect to cards */
        .card:hover {
            background-color: #e9ecef; /* Lighter gray on hover */
        }

        /* Red background for incorrect answers */
        .incorrect-card {
            background-color: #f8d7da; /* Light red for incorrect answer */
        }

        p {
    color: red;
    font-size: 18px;
    text-align: center;
    margin-top: 20px;
}
    </style>
</head>

<body>
    <div class="container">
        <?php
        // Include your database connection file
        include('C:\xampp\htdocs\FYP QUIZ WEBSITE\admin\database\quizdbconfig.php'); // Include your database connection file

        // Fetch data from user_answers table
        $sql = "SELECT q.quiz_name, qu.question, ua.selected_option, qu.correct_answer, ua.marks 
                FROM user_answers ua 
                JOIN questions qu ON ua.question_id = qu.question_id
                JOIN quizzes q ON ua.quiz_id = q.quiz_id
                ORDER BY ua.quiz_id"; // Order by quiz ID to group results
        
        $result = mysqli_query($conn, $sql);
        
        // Check if there are any results
        if (mysqli_num_rows($result) > 0) {
            echo "<h1>User Marks</h1>";
            $currentQuizId = null; // Initialize current quiz ID
            $totalMarks = 0; // Initialize total marks for each quiz ID
            while ($row = mysqli_fetch_assoc($result)) {
                if ($row['quiz_name'] !== $currentQuizId) { // Check if new quiz name
                    // Display total marks for previous quiz ID, if any
                    if ($currentQuizId !== null) {
                        echo "<div class='total-marks'>Total Marks: $totalMarks</div>";
                    }
                    // Start new card for the current quiz
                    echo "<div class='card'>";
                    echo "<div class='quiz-name'>Quiz Name: {$row['quiz_name']}</div>";
                    echo "<div class='marks-details'>";
                    $currentQuizId = $row['quiz_name']; // Update current quiz name
                    $totalMarks = 0; // Reset total marks for the new quiz ID
                }
        
                // Add marks to the total for the current quiz ID
                $totalMarks += $row['marks'];
        
                // Determine if the answer is correct or incorrect
                $cardClass = ($row['selected_option'] === $row['correct_answer']) ? '' : 'incorrect-card'; // Apply class only if incorrect
        
                // Display question details in the marks-details section with the appropriate card class
                echo "<div class='card $cardClass'>";
                echo "<div>Question: {$row['question']}</div>";
                echo "<div>Selected Option: {$row['selected_option']}</div>";
                echo "<div>Correct Answer: {$row['correct_answer']}</div>";
                echo "<div>Marks: {$row['marks']}</div>";
                echo "</div>"; // Close inner card for question details
            }
        
            // Display total marks for the last quiz ID
            echo "<div class='total-marks'>Total Marks: $totalMarks</div>";
        
            // Close the marks-details div and card
            echo "</div>"; // Close marks-details div
            echo "</div>"; // Close card div
        } else {
            echo "<p>No data found.</p>";
        }
        
        // Close the database connection
        mysqli_close($conn);
        ?>
        <!-- Homepage Button -->
        <a href="homepage.php" class="btn">Homepage</a>
    </div>
</body>

</html>
