<?php
// Include your database connection file for the admin database
include('C:\xampp\htdocs\FYP QUIZ WEBSITE\admin\database\quizdbconfig.php');

include('header.php');
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Semester 1 Subjects</title>
    <link rel="stylesheet" href="semester.css">
</head>

<body>
    <main class="main">
        <h1 class="title">SEMESTER 3 SUBJECTS</h1>

        <div class="table-responsive">
            <?php
            $connection = mysqli_connect("localhost", "root", "", "admin_quiz");
            $semester = "Semester 3"; // Specify the semester you want to display
            $query = "SELECT * FROM quizzes WHERE semester = '$semester' ORDER BY subject";
            $query_run = mysqli_query($connection, $query);

            if ($query_run && mysqli_num_rows($query_run) > 0) {
                $current_subject = null;
                while ($row = mysqli_fetch_assoc($query_run)) {
                    if ($current_subject !== $row['subject']) {
                        // Start a new section for each subject
                        if ($current_subject !== null) {
                            echo '</tbody></table>'; // Close the previous table if it's not the first subject
                        }
                        echo '<h2 style="color: white;">' . $row['subject'] . '</h2>';

                        echo '<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>Quiz Name</th>
                                        <th>Quiz Description</th>
                                        <th>Action</th> 
                                    </tr>
                                </thead>
                                <tbody>'; // Start a new table for the subject
                        $current_subject = $row['subject'];
                    }
            ?>
                    <tr>
                        <td><?php echo $row['quiz_name']; ?></td>
                        <td><?php echo $row['quiz_description']; ?></td>
                        <td>
                            <form action="semester2_subject.php" method="GET">
                                <input type="hidden" name="quiz_id" value="<?php echo $row['quiz_id']; ?>">
                                <button type="submit" name="start_quiz_btn" class="start-quiz-btn">Start Quiz</button>
                            </form>

                        </td>
                    </tr>
            <?php
                }
                echo '</tbody></table>'; // Close the last table
            } else {
                echo '<p style="color: blue;">No quizzes found for Semester 3.</p>';
            }
            ?>
        </div>
    </main>

    <?php include('ufooter.php'); ?>
</body>

</html>