

//java script for dropdown profile 
document.addEventListener("DOMContentLoaded", function() {
    var profileBtn = document.querySelector(".profile-btn");
    var dropdownContent = document.querySelector(".dropdown-content");

    profileBtn.addEventListener("click", function() {
        dropdownContent.classList.toggle("show");
    });

    window.addEventListener("click", function(event) {
        if (!event.target.matches(".profile-btn")) {
            dropdownContent.classList.remove("show");
        }
    });
});

//JAVASCRIPT FOR QUIZPOPUP INFO
document.addEventListener("DOMContentLoaded", function() {
    const startBtn = document.querySelector('.start-btn');
    const popupInfo = document.querySelector('.popup-info');
    const exitBtn = document.querySelector('.exit-btn');
    const continueBtn = document.querySelector('.continue-btn'); // Added selector for continue button
    let backdrop;

    startBtn.addEventListener('click', function() {
        popupInfo.classList.add('active');
        // Create and show backdrop
        backdrop = document.createElement('div');
        backdrop.classList.add('backdrop');
        document.body.appendChild(backdrop);

        // Optionally, blur the .main content when popup is active
        document.querySelector('.main').classList.add('blur');

        // Close popup when clicking on backdrop
        backdrop.addEventListener('click', function() {
            popupInfo.classList.remove('active');
            document.body.removeChild(backdrop);
            document.querySelector('.main').classList.remove('blur'); // Remove blur when closing
        });
    });

    exitBtn.addEventListener('click', function() {
        popupInfo.classList.remove('active');
        if (backdrop) document.body.removeChild(backdrop);
        document.querySelector('.main').classList.remove('blur'); // Remove blur when closing
    });

    // Handle click event for Continue Quiz button
    continueBtn.addEventListener('click', function() {
        // Redirect to your quiz page
        window.location.href = 'quiz.php'; // Replace 'path_to_your_quiz_page' with the actual URL
    });
});




