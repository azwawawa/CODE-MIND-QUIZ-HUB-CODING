<?php
session_start();
include('includes/header.php');
include('includes/navbar.php');

// Include your database connection file
include('database/quizdbconfig.php');

?>
<div class="container-fluid" style="margin-top: 30px;">

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="n-0 font-weight-bold text-primary" style="margin-top: 20px;"> Edit Quiz </h6>
        </div>
        <div class="card-body">

            <?php
            if (isset($_POST['edit_btn'])) {
                $quiz_id = $_POST['edit_quiz_id'];

                $query = "SELECT * FROM quizzes WHERE quiz_id='$quiz_id'";
                $query_run = mysqli_query($conn, $query);

                foreach ($query_run as $row) {
            ?>
                    <form action="dquizzes_code.php" method="POST">

                        <input type="hidden" name="edit_quiz_id" value="<?php echo $row['quiz_id'] ?>" class="form-control">

                        <div class="form-group">
                            <label> Quiz Name </label>
                            <input type="text" name="edit_quiz_name" value="<?php echo $row['quiz_name'] ?>" class="form-control" placeholder="Enter Quiz Name">
                        </div>
                        <div class="form-group">
                            <label> Quiz Description </label>
                            <input type="text" name="edit_quiz_description" value="<?php echo $row['quiz_description'] ?>" class="form-control" placeholder="Enter Quiz Description">
                        </div>
                        <div class="form-group">
                            <label> Semester </label>
                            <input type="text" name="edit_semester" value="<?php echo $row['semester'] ?>" class="form-control" placeholder="Enter Semester">
                        </div>
                        <div class="form-group">
                            <label> Subject </label>
                            <input type="text" name="edit_subject" value="<?php echo $row['subject'] ?>" class="form-control" placeholder="Enter Subject">
                        </div>
                        <div class="form-group">
                            <label> Created By </label>
                            <input type="text" name="edit_created_by" value="<?php echo $row['created_by'] ?>" class="form-control" placeholder="Enter Created By">
                        </div>
                        <!-- Add more form fields as needed -->

                        <a href="display_quizzes.php" class="btn btn-danger"> CANCEL </a>
                        <button type="submit" name="update_quiz_btn" class="btn btn-primary"> UPDATE </button>
                    </form>
            <?php
                }
            }
            ?>
        </div>
    </div>
</div>

<?php
include('includes/scripts.php');
?>
