<?php
session_start();
include('database/dbconfig.php');

include('includes/header.php');
include('includes/navbar.php');


$username = ''; // Initialize the username variable

if (isset($_SESSION['id'])) {
    $admin_id = $_SESSION['id'];

    // Ensure $conn is your valid database connection
    if ($conn) {
        // Prepare a SELECT statement to fetch the username of the logged-in user
        $sql = "SELECT username FROM register WHERE id = ?";
        if ($stmt = $conn->prepare($sql)) {
            $stmt->bind_param("i", $admin_id);
            if ($stmt->execute()) {
                $result = $stmt->get_result();
                if ($result->num_rows > 0) {
                    $row = $result->fetch_assoc();
                    $username = $row['username']; // Fetch the username
                } else {
                    echo "No user found with the ID.";
                }
            } else {
                echo "Execution failed: " . htmlspecialchars($stmt->error);
            }
            $stmt->close();
        } else {
            echo "Prepare failed: " . htmlspecialchars($conn->error);
        }
    } else {
        echo "Database connection not established.";
    }
}
    
// Check if the user is logged in and session variable is set
if (isset($_SESSION['username'])) {
    // Connect to the database
    $host = "localhost";
    $dbusername = "root"; // Replace with your actual database username
    $dbpassword = ""; // Replace with your actual database password
    $dbname = "adminpanel"; // Replace with your actual database name
    $conn = new mysqli($host, $dbusername, $dbpassword, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Fetch username from the database based on the logged-in user's session username
    $username = $_SESSION['username'];
    $sql = "SELECT username FROM register WHERE username = '$username'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $username = $row['username']; // Get the username from the database
        }
    }

    // Close the database connection
    $conn->close();
}

?>

<!-- Content Wrapper -->
<div id="content-wrapper" class="d-flex flex-column">

    <!-- Main Content -->
    <div id="content">

        <!-- Begin Page Content -->


        <div class="modal fade" id="addadminprofile" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Add Admin Data</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form action="code.php" method="POST">

                        <div class="modal-body">

                            <div class="form-group">
                                <label> Username </label>
                                <input type="text" name="username" class="form-control" placeholder="Enter Username">
                            </div>
                            <div class="form-group">
                                <label>Email</label>
                                <input type="email" name="email" class="form-control checking_email" placeholder="Enter Email">
                                <small class="error_email" style="color: red;"></small>
                            </div>
                            <div class="form-group">
                                <label>Password</label>
                                <input type="password" name="password" class="form-control" placeholder="Enter Password">
                            </div>
                            <div class="form-group">
                                <label>Confirm Password</label>
                                <input type="password" name="confirmpassword" class="form-control" placeholder="Confirm Password">
                            </div>


                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" name="registerbtn" class="btn btn-primary">Save</button>
                        </div>
                    </form>

                </div>
            </div>
        </div>

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

            <!-- Sidebar Toggle (Topbar) -->
            <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                <i class="fa fa-bars"></i>
            </button>

            <!-- Text "ADMIN PANEL" -->
            <div class="navbar-brand">
                <span class="font-weight-bold text-primary">ADMIN PANEL</span>
            </div>

            <!-- Topbar Navbar -->
            <ul class="navbar-nav ml-auto">
                

               <!-- Topbar Navbar -->
               <ul class="navbar-nav ml-auto">

<!-- Nav Item - User Information -->
<li class="nav-item dropdown no-arrow">
    <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo $username; ?></span> <!-- Display the username -->
        <img class="img-profile rounded-circle" src="img/undraw_profile.svg">
        <i class="fas fa-caret-down"></i>
    </a>

    <!-- Dropdown - User Information -->
    <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
        <a class="dropdown-item" href="#">
            <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
            Profile
        </a>
        <div class="dropdown-divider"></div>
        <a class="dropdown-item" href="login.php" data-toggle="modal" data-target="#logoutModal">
            <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
            Logout
        </a>
    </div>
</li>

</ul>

        </nav>
        <!-- End of Topbar -->

        <div class="container-fluid">

            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="n-0 font-weight-bold text-primary">Admin Profile
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addadminprofile">
                            Add Admin Profile
                        </button>
                    </h6>
                </div>
                <div class="card-body">

                    <?php
                    if (isset($_SESSION['success']) && $_SESSION['success'] != '') {

                        echo '<h2 class="bg-primary text-white">' . $_SESSION['success'] . '</h2>';
                        unset($_SESSION['success']);
                    }
                    if (isset($_SESSION['success']) && $_SESSION['status'] != '') {

                        echo '<h2 class="bg-danger">' . $_SESSION['status'] . '</h2>';
                        unset($_SESSION['status']);
                    }

                    ?>


                    <div class="table-responsive">

                        <?php
                        $connection = mysqli_connect("localhost", "root", "", "adminpanel");
                        $query = "SELECT * FROM register ";
                        $query_run = mysqli_query($connection, $query);

                        ?>

                        <table class=" table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Username</th>
                                    <th>Email</th>
                                    <th>Password</th>
                                    <th>EDIT</th>
                                    <th>DELETE</th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php
                                if (mysqli_num_rows($query_run) > 0) {
                                    while ($row = mysqli_fetch_assoc($query_run)) {
                                ?>
                                        <tr>
                                            <td><?php echo $row['id']; ?></td>
                                            <td><?php echo $row['username']; ?></td>
                                            <td><?php echo $row['email']; ?></td>
                                            <td><?php echo $row['password']; ?></td>



                                            <td>
                                                <form action="register_edit.php" method="post">
                                                    <input type="hidden" name="edit_id" value="<?php echo $row['id']; ?>">
                                                    <button type="submit" name="edit_btn" class="btn btn-success">EDIT</button>
                                                </form>

                                            </td>
                                            <td>
                                                <form action="code.php " method="post">
                                                    <input type="hidden" name="delete_id" value="<?php echo $row['id']; ?>">
                                                    <button type="submit" name="delete_btn" class="btn btn-danger">DELETE</button>
                                                </form>
                                            </td>

                                        </tr>
                                <?php
                                    }
                                } else {
                                    echo "No record found";
                                }
                                ?>
                            </tbody>
                        </table> <?php
                                    include('includes/scripts.php');
                                    include('includes/footer.php');
                                    ?>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>