<?php

include('database/security.php');

// Assuming your quizzes database connection details are correct
$connection = mysqli_connect("localhost", "root", "", "admin_quiz");

// Add a new quiz
if(isset($_POST['add_quiz_btn'])) {
    $quiz_name = $_POST['quiz_name'];
    $quiz_description = $_POST['quiz_description'];
    $semester = $_POST['semester'];
    $subject = $_POST['subject'];

    $query = "INSERT INTO quizzes (quiz_name, quiz_description, semester, subject) VALUES ('$quiz_name', '$quiz_description', '$semester', '$subject')";
    $query_run = mysqli_query($connection, $query);
            
    // Check if insertion was successful
    if ($query_run) {
        // Set success message for quiz form
        $_SESSION['quiz_success'] = "Quiz Added Successfully";

        // Redirect to quizform.php
        header("Location: quizform.php");
        exit; // Stop further execution
    } else {
        // Set failure message for quiz form
        $_SESSION['quiz_status'] = "Failed to add quiz.";

        // Redirect to quizform.php
        header("Location: quizform.php");
        exit; // Stop further execution
    }
}


// Update an existing quiz
if(isset($_POST['update_quiz_btn'])) {
    $quiz_id = $_POST['edit_quiz_id'];
    $quiz_name = $_POST['edit_quiz_name'];
    $quiz_description = $_POST['edit_quiz_description'];
    $semester = $_POST['edit_semester'];
    $subject = $_POST['edit_subject'];

    $query = "UPDATE quizzes SET quiz_name='$quiz_name', quiz_description='$quiz_description', semester='$semester', subject='$subject' WHERE quiz_id='$quiz_id'";

    $query_run = mysqli_query($connection, $query);

       // Check if insertion was successful
if ($query_run) {
    // Set success message for quiz form
    $_SESSION['quiz_success'] = "Quiz Added Successfully";

    // Redirect to quizform.php
    header("Location: display_quizzes.php");
    exit; // Stop further execution
} else {
    // Set failure message for quiz form
    $_SESSION['quiz_status'] = "Failed to add quiz.";

    // Redirect to quizform.php
    header("Location: quizform.php");
    exit; // Stop further execution
}

   
}



// Delete a quiz and its related questions
if(isset($_POST['delete_quiz_btn'])) {
    $quiz_id = $_POST['delete_quiz_id'];
    
    // Delete questions related with the quiz ID
    $query_delete_questions = "DELETE FROM questions WHERE quiz_id='$quiz_id'";
    $query_run_delete_questions = mysqli_query($connection, $query_delete_questions);

    // Delete the quiz itself
    $query_delete_quiz = "DELETE FROM quizzes WHERE quiz_id='$quiz_id'";
    $query_run_delete_quiz = mysqli_query($connection, $query_delete_quiz);

    if($query_run_delete_questions && $query_run_delete_quiz) {
        $_SESSION['quiz_success'] = "Quiz and related Questions Deleted Successfully";
        header('Location: display_quizzes.php');
        exit(); // Exit to avoid further execution
    } else {
        $_SESSION['quiz_status'] = "Quiz and related Questions Not Deleted";
        header('Location: display_quizzes.php');
        exit(); // Exit to avoid further execution
    }
}



//Add new questions
if(isset($_POST['add_question_btn'])) {
    $quiz_id = $_POST['quiz_id']; // Ensure this is passed from your form
    $question = $_POST['question'];
    $option1 = $_POST['option1'];
    $option2 = $_POST['option2'];
    $option3 = $_POST['option3'];
    $option4 = $_POST['option4'];
    $correct_answer = $_POST['correct_answer'];

    $query = "INSERT INTO questions (quiz_id, question, option1, option2, option3, option4, correct_answer) VALUES ('$quiz_id', '$question', '$option1', '$option2', '$option3', '$option4', '$correct_answer')";
    $query_run = mysqli_query($connection, $query);
            
    if($query_run) {
        $_SESSION['success'] = "Question Added Successfully";
        header('Location: questionform.php'); // Redirect after successful addition
    } else {
        $_SESSION['status'] = "Question Not Added";
        header('Location: questionform.php'); // Redirect on failure
    }
    
}

// Update an existing question
if(isset($_POST['update_question_btn'])) {
    $question_id = $_POST['edit_question_id'];
    $quiz_id = $_POST['edit_id']; // Assuming you want to allow changing the quiz as well
    $question = $_POST['edit_question'];
    $option1 = $_POST['edit_option1'];
    $option2 = $_POST['edit_option2'];
    $option3 = $_POST['edit_option3'];
    $option4 = $_POST['edit_option4'];
    $correct_answer = $_POST['edit_correct_answer'];

    $query = "UPDATE questions SET quiz_id='$quiz_id', question='$question', option1='$option1', option2='$option2', option3='$option3', option4='$option4', correct_answer='$correct_answer' WHERE question_id='$question_id'";

    $query_run = mysqli_query($connection, $query);

    if($query_run) {
        $_SESSION['success'] = "Question Updated Successfully";
        header('Location: display_questions.php'); // Redirect after successful update
        exit(); // Exit to avoid further execution
    } else {
        $_SESSION['status'] = "Question Not Updated";
        header('Location: display_questions.php'); // Redirect on failure
        exit(); // Exit to avoid further execution
    }
    
}

// Delete a question
if(isset($_POST['delete_question_btn'])) {
    $question_id = $_POST['delete_id'];

    $query = "DELETE FROM questions WHERE question_id='$question_id'";
    $query_run = mysqli_query($connection, $query);

    if($query_run) {
        $_SESSION['success'] = "Question Deleted Successfully";
        header('Location: display_questions.php'); // Redirect after successful deletion
        exit(); // Exit to avoid further execution
    } else {
        $_SESSION['status'] = "Question Not Deleted";
        header('Location: display_questions.php'); // Redirect on failure
        exit(); // Exit to avoid further execution
    }
}

?> <?php include('includes/scripts.php'); ?>