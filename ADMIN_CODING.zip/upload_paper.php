<?php
// Include database connection file
$servername = "localhost"; 
$username = "root";
$password = ""; 
$dbname = "adminpapers"; 

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $paper_title = $_POST['paper_title'];
    $paper_description = $_POST['paper_description'];
    $faculty = $_POST['faculty'];
    $subject = $_POST['subject'];

    // File upload handling
    $file_name = $_FILES['file']['name'];
    $file_tmp = $_FILES['file']['tmp_name'];
    $file_path = "uploads/" . $file_name; // Assuming uploads/ is a writable directory

    move_uploaded_file($file_tmp, $file_path);

    // Insert data into adminpapers table with prepared statement
    $stmt = $conn->prepare("INSERT INTO adminpapers (paper_title, paper_description, faculty, subject, file_name, file_path) 
                            VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $paper_title, $paper_description, $faculty, $subject, $file_name, $file_path);

    if ($stmt->execute()) {
        // Insert data into past_paper table in the user panel database
        $past_paper = new mysqli("localhost", "root",  "", "past_paper"); // Update with actual user panel database credentials

        if ($conn_user->connect_error) {
            die("User panel connection failed: " . $conn_user->connect_error);
        }

        $stmt_user = $conn_user->prepare("INSERT INTO past_paper (paper_title, paper_description, faculty, subject) 
                                          VALUES (?, ?, ?, ?)");
        $stmt_user->bind_param("ssss", $paper_title, $paper_description, $faculty, $subject);

        if ($stmt_user->execute()) {
            echo "Paper submitted successfully.";
        } else {
            echo "Error: " . $stmt_user->error;
        }

        $stmt_user->close();
        $conn_user->close();
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>
