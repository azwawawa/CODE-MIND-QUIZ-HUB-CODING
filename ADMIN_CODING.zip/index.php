<?php

include('database/security.php');
include('database/dbconfig.php');
include('includes/header.php');
include('includes/navbar.php');
// Check if the user is logged in and session variable is set
if (isset($_SESSION['username'])) {
    // Connect to the database
    $host = "localhost";
    $dbusername = "root"; // Replace with your actual database username
    $dbpassword = ""; // Replace with your actual database password
    $dbname = "adminpanel"; // Replace with your actual database name
    $conn = new mysqli($host, $dbusername, $dbpassword, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Fetch username from the database based on the logged-in user's session username
    $username = $_SESSION['username'];
    $sql = "SELECT username FROM register WHERE username = '$username'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $username = $row['username']; // Get the username from the database
        }
    }

    // Close the database connection
    $conn->close();
}

?>

<!-- Content Wrapper -->
<div id="content-wrapper" class="d-flex flex-column">

    <!-- Main Content -->
    <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

            <!-- Sidebar Toggle (Topbar) -->
            <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                <i class="fa fa-bars"></i>
            </button>

            <!-- Text "ADMIN PANEL" -->
            <div class="navbar-brand">
                <span class="font-weight-bold text-primary">ADMIN PANEL</span>
            </div>

            <!-- Topbar Navbar -->
            <ul class="navbar-nav ml-auto">

<!-- Nav Item - User Information -->
<li class="nav-item dropdown no-arrow">
    <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo $username; ?></span> <!-- Display the username -->
        <img class="img-profile rounded-circle" src="img/undraw_profile.svg">
        <i class="fas fa-caret-down"></i>
    </a>

    <!-- Dropdown - User Information -->
    <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
        <a class="dropdown-item" href="#">
            <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
            Profile
        </a>
        <div class="dropdown-divider"></div>
        <a class="dropdown-item" href="login.php" data-toggle="modal" data-target="#logoutModal">
            <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
            Logout
        </a>
    </div>
</li>

</ul>


        </nav>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">

            <!-- Page Heading -->
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
                <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
            </div>

            <!-- Content Row -->
            <div class="row">

                <!-- Total Registered Admin Card -->
                <div class="col-xl-3 col-md-6 mb-4">
                    <div class="card border-left-primary shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                    <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                        Total Registered Admin
                                    </div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800">
                                        <?php
                                        require 'database/dbconfig.php';
                                        $query = "SELECT id FROM register ORDER BY id";
                                        $query_run = mysqli_query($connection, $query);

                                        $row = mysqli_num_rows($query_run);
                                        echo '<h1>' . $row . '</h1>';
                                        ?>
                                    </div>
                                </div>
                                <div class="col-auto">
                                    <i class="fas fa-calendar fa-2x text-gray-300"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Quick Access Buttons -->
                <div class="col-xl-3 col-md-6 mb-4">
                    <div class="card border-left-primary shadow h-100 py-2 custom-card">
                        <a href="register.php" class="btn btn-icon-split btn-block">
                            <div class="card-body">
                                <span class="icon text-white-50">
                                    <i class="fas fa-user-circle fa-4x"></i>
                                </span>
                                <span class="text">Admin Profile</span>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6 mb-4">
                    <div class="card border-left-primary shadow h-100 py-2 custom-card">
                        <a href="quizform.php" class="btn btn-icon-split btn-block">
                            <div class="card-body">
                                <span class="icon text-white-50">
                                    <i class="fas fa-plus-circle fa-4x"></i>
                                </span>
                                <span class="text">Add New Quizzes</span>
                            </div>
                        </a>
                    </div>
                </div>

                <!-- Add New Question -->
                <div class="col-xl-3 col-md-6 mb-4">
                    <div class="card border-left-primary shadow h-100 py-2 custom-card">
                        <a href="questionform.php" class="btn btn-icon-split btn-block">
                            <div class="card-body">
                                <span class="icon text-white-50">
                                    <i class="fas fa-plus-circle fa-4x"></i>
                                </span>
                                <span class="text">Add New Questions</span>
                            </div>
                        </a>
                    </div>
                </div>

                <!-- Add New Past Year Button -->
                <div class="col-xl-3 col-md-6 mb-4">
                    <div class="card border-left-primary shadow h-100 py-2 custom-card">
                        <a href="addpaper.php" class="btn btn-icon-split btn-block">
                            <div class="card-body">
                                <span class="icon text-white-50">
                                    <i class="fas fa-calendar-plus fa-4x"></i>
                                </span>
                                <span class="text">Add New Paper</span>
                            </div>
                        </a>
                    </div>
                </div>



                <!-- Other Content Cards (if any) -->

            </div>




        </div>
        <!-- /.container-fluid -->

    </div>
    <!-- End of Main Content -->


    <?php
    include('includes/scripts.php');
    include('includes/footer.php');
    ?>


    


    <style>
        .custom-card {
            background-color: #ffffff;
            transition: background-color 0.3s ease;
        }

        .custom-card:hover {
            background-color: lightblue;
        }
    </style>