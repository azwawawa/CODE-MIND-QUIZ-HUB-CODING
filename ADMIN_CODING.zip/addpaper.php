<?php
include('database/paperdbconfig.php');
include('database/dbconfig.php');

session_start();

// Add the paper in the database
if (isset($_POST['add_paper'])) {
    $paper_title = $_POST['paper_title'];
    $paper_description = $_POST['paper_description'];
    $faculty = $_POST['faculty'];
    $subject = $_POST['subject'];

    // Define the path to the file download directory (adjust this path based on your configuration)
    $downloadDirectory = '/path/to/your/uploads/directory/';

   
    // Create the full path to the file
    $filePath = $downloadDirectory . $fileName;

    // Check if the file exists
    if (file_exists($filePath)) {
        // Set headers to download the file
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . basename($filePath) . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($filePath));
        flush(); // Flush system output buffer
        readfile($filePath);
        exit;
    } else {
        echo "The requested file does not exist.";
    }
    if (move_uploaded_file($uploaded_file, $target_file)) {
        echo "File uploaded successfully.";
    } else {
        echo "Error uploading file.";
    }

    // Insert data into 'pastpaper' table
    $insert_query = mysqli_query($conn, "INSERT INTO `pastpaper` (paper_title, paper_description, faculty, subject, file_path) VALUES ('$paper_title', '$paper_description', '$faculty', '$subject', '$uploadDirectory" . $_FILES['file']['name'] . "')");

    // Add debug messages to check SQL query execution
    if ($insert_query) {
        echo "Data inserted successfully.";
    } else {
        echo "Error inserting data: " . mysqli_error($conn);
    }

    // Check if insertion was successful
    if ($insert_query) {
        // Set success message
        $_SESSION['success'] = "Paper Added Successfully";

        // Redirect to display_paper.php
        header('Location: display_paper.php');
        exit; // Stop further execution
    } else {
        echo "Failed to add paper.";
    }
}

// Check if the user is logged in and session variable is set
if (isset($_SESSION['username'])) {
    // Connect to the database
    $host = "localhost";
    $dbusername = "root"; // Replace with your actual database username
    $dbpassword = ""; // Replace with your actual database password
    $dbname = "adminpanel"; // Replace with your actual database name
    $conn = new mysqli($host, $dbusername, $dbpassword, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Fetch username from the database based on the logged-in user's session username
    $username = $_SESSION['username'];
    $sql = "SELECT username FROM register WHERE username = '$username'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $username = $row['username']; // Get the username from the database
        }
    }

    // Close the database connection
    $conn->close();
}


?>






<!DOCTYPE html>
<html lang="en">

<head>
    <?php
    include('includes/header.php');
    include('includes/navbar.php');
    ?>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Past Paper</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        h1 {
            text-align: center;
            margin-top: 20px;
            margin-left: 20px;
        }

        table {

            width: 70%;
            margin-top: 50px;
            margin-left: 200px;
            border-collapse: collapse;
        }

        td,
        th {
            border: 1px solid #ddd;
            padding: 8px;
        }

        td {
            text-align: left;
        }

        label {
            margin-bottom: 5px;
            display: inline-block;
        }

        input[type="text"],
        textarea,
        select {
            width: 95%;
            padding: 8px;
            margin: 5px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button[type="submit"] {
            width: auto;
            background-color: #007bff;
            color: white;
            padding: 5px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            float: right;
        }

        button[type="submit"]:hover {
            background-color: #0056b3;
        }

        .form-group {
            margin-bottom: 20px;
        }
    </style>
</head>

<body>
    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <div id="content">
            <!-- Topbar -->
            <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                <!-- Sidebar Toggle (Topbar) -->
                <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                    <i class="fa fa-bars"></i>
                </button>

                <!-- Text "ADMIN PANEL" -->
                <div class="navbar-brand">
                    <span class="font-weight-bold text-primary">ADMIN PANEL</span>
                </div>

                <!-- Topbar Navbar -->
                <ul class="navbar-nav ml-auto">

                    <!-- Nav Item - User Information -->
                    <li class="nav-item dropdown no-arrow">
                        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo $username; ?></span> <!-- Display the username -->
                            <img class="img-profile rounded-circle" src="img/undraw_profile.svg">
                            <i class="fas fa-caret-down"></i>
                        </a>

                        <!-- Dropdown - User Information -->
                        <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                            <a class="dropdown-item" href="#">
                                <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                Profile
                            </a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="login.php" data-toggle="modal" data-target="#logoutModal">
                                <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                Logout
                            </a>
                        </div>
                    </li>

                </ul>

            </nav>
            <!-- End of Topbar -->

            <div class="container mt-4">
                <h1 class="mb-4">Upload Paper</h1>
                <form action="" method="post" enctype="multipart/form-data">

                    <div class="form-group">
                        <label for="paper_title">Paper Title:</label>
                        <input type="text" class="form-control" id="paper_title" name="paper_title" required>
                    </div>
                    <div class="form-group">
                        <label for="paper_description">Paper Description:</label>
                        <textarea class="form-control" id="paper_description" name="paper_description" rows="4" required></textarea>
                    </div>
                    <div class="form-group">
                        <label for="faculty">Choose Faculty:</label>
                        <select name="faculty" id="faculty" onchange="updateSubjects()">
                            <option value="fcom">Faculty of Computing & Multimedia</option>
                            <option value="fbus">Faculty of Business, Accountancy & Social Sciences</option>
                            <option value="fedu">Faculty of Education, Social Sciences & Humanities</option>
                            <option value="ips">Institute of Professional Studies</option>
                            <option value="igs">Institute of Graduate Studies</option>
                            <option value="cigs">Centre of Islamic, General & Language Studies</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="subject">Choose Subject:</label>
                        <select class="form-control" id="subject" name="subject" required>
                            <!-- Default option -->
                            <option value="">Select Faculty First</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="file_path">Choose File:</label>
                        <input type="file" class="form-control-file" id="file" name="file" required>
                    </div>
                    <td colspan="2"><button type="submit" name="add_paper">Upload Paper</button></td>
                </form>
            </div>
            <script>
                function updateSubjects() {
                    var facultyDropdown = document.getElementById("faculty");
                    var subjectDropdown = document.getElementById("subject");
                    var selectedFaculty = facultyDropdown.value;

                    // Clear existing options
                    subjectDropdown.innerHTML = "";

                    // Add default option
                    var defaultOption = document.createElement("option");
                    defaultOption.text = "Select Subject";
                    defaultOption.value = "";
                    subjectDropdown.add(defaultOption);

                    // Add subjects based on selected faculty
                    if (selectedFaculty === "fcom") {
                        var compSciOption1 = new Option("Computer Science", "compsci");
                        var compSciOption2 = new Option("Programming", "programming");
                        var compSciOption3 = new Option("Networking", "networking");
                        var compSciOption4 = new Option("Database Management", "database");
                        var compSciOption5 = new Option("Web Development", "webdev");
                        var compSciOption6 = new Option("Graphics Design", "graphics");
                        var compSciOption7 = new Option("Animation", "animation");

                        subjectDropdown.add(compSciOption1);
                        subjectDropdown.add(compSciOption2);
                        subjectDropdown.add(compSciOption3);
                        subjectDropdown.add(compSciOption4);
                        subjectDropdown.add(compSciOption5);
                        subjectDropdown.add(compSciOption6);
                        subjectDropdown.add(compSciOption7);
                    } else if (selectedFaculty === "fbus") {
                        var businessOption1 = new Option("Accounting", "accounting");
                        var businessOption2 = new Option("Economics", "economics");
                        var businessOption3 = new Option("Management", "management");
                        var businessOption4 = new Option("Marketing", "marketing");

                        subjectDropdown.add(businessOption1);
                        subjectDropdown.add(businessOption2);
                        subjectDropdown.add(businessOption3);
                        subjectDropdown.add(businessOption4);

                    } else if (selectedFaculty === "fedu") {
                        var eduOption1 = new Option("Education Studies", "education");
                        var eduOption2 = new Option("Psychology", "psychology");
                        var eduOption3 = new Option("Sociology", "sociology");
                        var eduOption4 = new Option("History", "history");

                        subjectDropdown.add(eduOption1);
                        subjectDropdown.add(eduOption2);
                        subjectDropdown.add(eduOption3);
                        subjectDropdown.add(eduOption4);
                    } else if (selectedFaculty === "ips") {
                        var ipsOption1 = new Option("Law Studies", "law");
                        var ipsOption2 = new Option("Finance", "finance");
                        var ipsOption3 = new Option("Human Resource Management", "hr");
                        var ipsOption4 = new Option("Leadership Studies", "leadership");

                        subjectDropdown.add(ipsOption1);
                        subjectDropdown.add(ipsOption2);
                        subjectDropdown.add(ipsOption3);
                        subjectDropdown.add(ipsOption4);
                    } else if (selectedFaculty === "igs") {
                        var igsOption1 = new Option("Research Methodology", "research");
                        var igsOption2 = new Option("Thesis Writing", "thesis");
                        var igsOption3 = new Option("Statistics", "statistics");
                        var igsOption4 = new Option("Ethics in Research", "ethics");

                        subjectDropdown.add(igsOption1);
                        subjectDropdown.add(igsOption2);
                        subjectDropdown.add(igsOption3);
                        subjectDropdown.add(igsOption4);
                    } else if (selectedFaculty === "cigs") {
                        var cigsOption1 = new Option("Islamic Studies", "islamic");
                        var cigsOption2 = new Option("Language Studies", "language");
                        var cigsOption3 = new Option("Philosophy", "philosophy");
                        var cigsOption4 = new Option("Cultural Studies", "culture");

                        subjectDropdown.add(cigsOption1);
                        subjectDropdown.add(cigsOption2);
                        subjectDropdown.add(cigsOption3);
                        subjectDropdown.add(cigsOption4);
                    }
                }
            </script>
</body>
<?php
include('includes/scripts.php');
include('includes/footer.php');
?>

</html>