<?php
session_start();
include('includes/header.php');
include('includes/navbar.php');

// Include your database connection file
include('database/quizdbconfig.php');

?>
<div class="container-fluid" style="margin-top: 30px;">

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="n-0 font-weight-bold text-primary" style="margin-top: 20px;"> Edit Question </h6>
        </div>
        <div class="card-body">

            <?php
            if (isset($_POST['edit_btn'])) {
                $question_id = $_POST['edit_question_id'];

                $query = "SELECT * FROM questions WHERE question_id='$question_id'";
                $query_run = mysqli_query($conn, $query);

                foreach ($query_run as $row) {
            ?>
                    <form action="dquizzes_code.php" method="POST">

                    <input type="hidden" name="edit_question_id" value="<?php echo $row['question_id']; ?>"class="form-control">

                        <div class="form-group">
                            <label> Question Text </label>
                            <input type="text" name="edit_question" value="<?php echo $row['question'] ?>" class="form-control" placeholder="Enter Question Text">
                        </div>
                        <div class="form-group">
                            <label> Option 1 </label>
                            <input type="text" name="edit_option1" value="<?php echo $row['option1'] ?>" class="form-control" placeholder="Enter Option 1">
                        </div>
                        <div class="form-group">
                            <label> Option 2 </label>
                            <input type="text" name="edit_option2" value="<?php echo $row['option2'] ?>" class="form-control" placeholder="Enter Option 2">
                        </div>
                        <div class="form-group">
                            <label> Option 3 </label>
                            <input type="text" name="edit_option3" value="<?php echo $row['option3'] ?>" class="form-control" placeholder="Enter Option 3">
                        </div>
                        <div class="form-group">
                            <label> Option 4 </label>
                            <input type="text" name="edit_option4" value="<?php echo $row['option4'] ?>" class="form-control" placeholder="Enter Option 4">
                        </div>
                        <div class="form-group">
                            <label> Correct Answer </label>
                            <input type="text" name="edit_correct_answer" value="<?php echo $row['correct_answer'] ?>" class="form-control" placeholder="Enter Correct Answer">
                        </div>
                       

                        <a href="display_questions.php" class="btn btn-danger"> CANCEL </a>
                        <button type="submit" name="update_question_btn" class="btn btn-primary"> UPDATE </button>
                    </form>
            <?php
                }
            }
            ?>
        </div>
    </div>
</div>
