<?php
include('database/quizdbconfig.php');
include('database/dbconfig.php');


// Add the question to the database
if (isset($_POST['add_question'])) {
    $quiz_id = mysqli_real_escape_string($conn, $_POST['quiz_id']);
    $question = mysqli_real_escape_string($conn, $_POST['question']);
    $option1 = mysqli_real_escape_string($conn, $_POST['option1']);
    $option2 = mysqli_real_escape_string($conn, $_POST['option2']);
    $option3 = mysqli_real_escape_string($conn, $_POST['option3']);
    $option4 = mysqli_real_escape_string($conn, $_POST['option4']);
    $correct_answer = mysqli_real_escape_string($conn, $_POST['correct_answer']);

    // Insert into SQL table using prepared statement
    $insert_query = $conn->prepare("INSERT INTO `questions` (quiz_id, question, option1, option2, option3, option4, correct_answer) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $insert_query->bind_param("issssss", $quiz_id, $question, $option1, $option2, $option3, $option4, $correct_answer);
    
    if ($insert_query->execute()) {
        // Question added successfully
        echo "Question added successfully.";
    } else {
        // Error adding question
        echo "Error: " . $insert_query->error;
    }

    // Close the prepared statement
    $insert_query->close();
}


// Initialize the username variable
$username = "";

/// Check if the user is logged in and session variable is set
if (isset($_SESSION['username'])) {
    // Connect to the database
    $host = "localhost";
    $dbusername = "root"; // Replace with your actual database username
    $dbpassword = ""; // Replace with your actual database password
    $dbname = "adminpanel"; // Replace with your actual database name
    $conn = new mysqli($host, $dbusername, $dbpassword, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Fetch username from the database based on the logged-in user's session username
    $username = $_SESSION['username'];
    $sql = "SELECT username FROM register WHERE username = '$username'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $username = $row['username']; // Get the username from the database
        }
    }

    // Close the database connection
    $conn->close();
}

?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Question</title>

    <?php
    include('includes/header.php');
    include('includes/navbar.php');
    ?>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        h1 {
            text-align: center;
            margin-top: 20px;
            margin-left: 50px;
        }

        table {
            width: 100%;
            margin-top: 40px;
            margin-bottom: 40px;
            border-collapse: collapse;
        }

        td,
        th {
            border: 1px solid #ddd;
            padding: 8px;
        }

        label {
            margin-bottom: 5px;
            display: inline-block;
        }

        input[type="text"],
        textarea,
        select {
            width: 95%;
            padding: 8px;
            margin: 5px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button[type="submit"] {
            width: auto;
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            margin: 10px 0;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            float: right;
        }

        button[type="submit"]:hover {
            background-color: #0056b3;
        }

        .form-group {
            margin-bottom: 60px;
        }
    </style>
</head>

<body>

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <div id="content">
            <!-- Topbar -->
            <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                <!-- Sidebar Toggle (Topbar) -->
                <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                    <i class="fa fa-bars"></i>
                </button>

                <!-- Text "ADMIN PANEL" -->
                <div class="navbar-brand">
                    <span class="font-weight-bold text-primary">ADMIN PANEL</span>
                </div>

                <!-- Topbar Navbar -->
                <ul class="navbar-nav ml-auto">

                    <!-- Nav Item - User Information -->
                    <li class="nav-item dropdown no-arrow">
                        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo $username; ?></span> <!-- Display the username -->
                            <img class="img-profile rounded-circle" src="img/undraw_profile.svg">
                            <i class="fas fa-caret-down"></i>
                        </a>


                        <!-- Dropdown - User Information -->
                        <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                            <a class="dropdown-item" href="register.php">
                                <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                Profile
                            </a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="login.php" data-toggle="modal" data-target="#logoutModal">
                                <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                Logout
                            </a>
                        </div>
                    </li>

                </ul>


            </nav>
            <!-- End of Topbar -->
            <header>
            <h1 style="color: black;">Add Question</h1>
            </header>
            <div class="container">
                <form action="" method="POST">
                    <table>
                        <tr>
                            <td><label for="quiz_id">Quiz:</label></td>
                            <td>
                                <select id="quiz_id" name="quiz_id" required>
                                    <?php
                                    // Fetch quiz_id and quiz_name options from the database
                                    $quiz_query = mysqli_query($conn, "SELECT quiz_id, quiz_name FROM quizzes") or die('Quiz query failed');
                                    while ($row = mysqli_fetch_assoc($quiz_query)) {
                                        echo "<option value='" . $row['quiz_id'] . "'>" . $row['quiz_name'] . "</option>";
                                    }
                                    ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td><label for="question">Question:</label></td>
                            <td><textarea id="question" name="question" rows="4" required></textarea></td>
                        </tr>
                        <tr>
                            <td><label for="option1">Option A:</label></td>
                            <td><input type="text" id="option1" name="option1" required></td>
                        </tr>
                        <tr>
                            <td><label for="option2">Option B:</label></td>
                            <td><input type="text" id="option2" name="option2" required></td>
                        </tr>
                        <tr>
                            <td><label for="option3">Option C:</label></td>
                            <td><input type="text" id="option3" name="option3" required></td>
                        </tr>
                        <tr>
                            <td><label for="option4">Option D:</label></td>
                            <td><input type="text" id="option4" name="option4" required></td>
                        </tr>
                        <tr>
                            <td><label for="correct_answer">Correct Answer:</label></td>
                            <td>
                                <select id="correct_answer" name="correct_answer" required>
                                    <option value="option1">Option A</option>
                                    <option value="option2">Option B</option>
                                    <option value="option3">Option C</option>
                                    <option value="option4">Option D</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2"><button type="submit" name="add_question">Submit Question</button></td>
                        </tr>
                    </table>
                </form>
            </div>

</body>
<?php
include('includes/scripts.php');
include('includes/footer.php');
?>
</html>