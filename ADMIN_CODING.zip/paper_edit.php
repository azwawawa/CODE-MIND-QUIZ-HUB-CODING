<?php
session_start();
include('includes/header.php');
include('includes/navbar.php');

// Include your database connection file for the "pastyear" database
include('database/paperdbconfig.php');

?>
<div class="container-fluid" style="margin-top: 30px;">
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="n-0 font-weight-bold text-primary" style="margin-top: 20px;"> Edit Paper </h6>
        </div>
        <div class="card-body">
            <?php
            if (isset($_POST['edit_paper_btn'])) {
                $paper_id = $_POST['edit_paper_id'];

                $query = "SELECT * FROM pastpaper WHERE paper_id='$paper_id'";
                $query_run = mysqli_query($conn, $query);

                foreach ($query_run as $row) {
            ?>
                    <form action="papercode.php" method="POST" >
                        <input type="hidden" name="edit_paper_id" value="<?php echo $row['paper_id'] ?>" class="form-control">
                        <div class="form-group">
                            <label> Paper Title </label>
                            <input type="text" name="edit_paper_title" value="<?php echo $row['paper_title'] ?>" class="form-control" placeholder="Enter Paper Title">
                        </div>
                        <div class="form-group">
                            <label> Paper Description </label>
                            <input type="text" name="edit_paper_description" value="<?php echo $row['paper_description'] ?>" class="form-control" placeholder="Enter Paper Description">
                        </div>
                        <div class="form-group">
                            <label> Faculty </label>
                            <input type="text" name="edit_faculty" value="<?php echo $row['faculty'] ?>" class="form-control" placeholder="Enter Faculty">
                        </div>
                        <div class="form-group">
                            <label> Subject </label>
                            <input type="text" name="edit_subject" value="<?php echo $row['subject'] ?>" class="form-control" placeholder="Enter Subject">
                        </div>
                       
                        <a href="display_paper.php" class="btn btn-danger"> CANCEL </a>
                        <button type="submit" name="update_paper_btn" class="btn btn-primary"> UPDATE </button>
                    </form>
            <?php
                }
            }
            ?>
        </div>
    </div>
</div>
<?php
include('includes/scripts.php');
?>
