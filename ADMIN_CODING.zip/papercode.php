<?php

include('database/security.php');


$connection = mysqli_connect("localhost", "root", "", "adminpapers");

// Add new papers
if(isset($_POST['add_paper_btn'])) {
    $paper_title = $_POST['paper_title'];
    $paper_description = $_POST['paper_description'];
    $faculty = $_POST['faculty'];
    $subject = $_POST['subject'];

    // Specify upload directory path
    $uploadDirectory = 'uploads/';

    // Handle file upload
    $uploaded_file = $_FILES['file']['tmp_name'];
    $target_file = $uploadDirectory . $_FILES['file']['name'];
    

    if (move_uploaded_file($uploaded_file, $target_file)) {
        // Insert paper details into the database
        $query = "INSERT INTO `pastpaper` (paper_title, paper_description, faculty, subject, file_path) VALUES ('$paper_title', '$paper_description', '$faculty', '$subject', '$uploadDirectory" . $_FILES['file']['name'] . "')";

        $query_run = mysqli_query($connection, $query);
                
        /*if($query_run) {
            $_SESSION['success'] = "Paper Added Successfully";
            header('Location: addpaper.php'); // Redirect after successful addition
        } else {
            $_SESSION['status'] = "Paper Not Added";
            header('Location: addpaper.php'); // Redirect on failure
        }
    } else {
        $_SESSION['status'] = "Error uploading file";
        header('Location: addpaper.php'); // Redirect on file upload failure*/
    }
    exit(); // Exit to avoid further execution
}


// Update an existing paper
if(isset($_POST['update_paper_btn'])) {
    $paper_id = $_POST['edit_paper_id']; // Make sure to capture the paper ID from the form
    $paper_title = $_POST['edit_paper_title'];
    $paper_description = $_POST['edit_paper_description'];
    $faculty = $_POST['edit_faculty'];
    $subject = $_POST['edit_subject'];

    $query = "UPDATE pastpaper SET paper_title='$paper_title', paper_description='$paper_description', faculty='$faculty', subject='$subject' WHERE paper_id='$paper_id'";

    $query_run = mysqli_query($connection, $query);

    if($query_run) {
        $_SESSION['success_paper'] = "Paper Updated Successfully";
        header('Location: display_paper.php'); // Redirect after successful update
    } else {
        $_SESSION['status'] = "Paper Not Updated";
        header('Location: display_paper.php'); // Redirect on failure
    }
    exit(); // Exit to avoid further execution
}

// Delete a paper
if(isset($_POST['delete_paper_btn'])) {
    $paper_id = $_POST['delete_paper_id']; // Make sure to capture the paper ID from the form

    $query = "DELETE FROM pastpaper WHERE paper_id='$paper_id'";
    $query_run = mysqli_query($connection, $query);

    if($query_run) {
        $_SESSION['success'] = "Paper Deleted Successfully";
        header('Location: display_paper.php'); // Redirect after successful deletion
    } else {
        $_SESSION['status'] = "Paper Not Deleted";
        header('Location: display_paper.php'); // Redirect on failure
    }
    exit(); // Exit to avoid further execution
}
?>