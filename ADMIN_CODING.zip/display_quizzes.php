<?php

// Include your database connection file
include('database/quizdbconfig.php');


include('includes/header.php');
include('includes/navbar.php');


// Fetch quizzes data from the database
$sql_quizzes = "SELECT * FROM quizzes";
$result_quizzes = mysqli_query($conn, $sql_quizzes);

// Check if query was successful
if (!$result_quizzes) {
    die("Error fetching quizzes: " . mysqli_error($conn));
}



?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Display Quizzes</title>

</head>

<body>
    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <div id="content">
            <!-- Topbar -->
            <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                <!-- Sidebar Toggle (Topbar) -->
                <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                    <i class="fa fa-bars"></i>
                </button>

                <!-- Text "ADMIN PANEL" -->
                <div class="navbar-brand">
                    <span class="font-weight-bold text-primary">ADMIN PANEL</span>
                </div>

                <!-- Topbar Navbar -->
                <ul class="navbar-nav ml-auto">

                    <!-- Nav Item - User Information -->
                    <li class="nav-item dropdown no-arrow">
                        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span class="mr-2 d-none d-lg-inline text-gray-600 small"></span> <!-- Display the username -->
                            <img class="img-profile rounded-circle" src="img/undraw_profile.svg">
                            <i class="fas fa-caret-down"></i>
                        </a>

                        <!-- Dropdown - User Information -->
                        <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                            <a class="dropdown-item" href="#">
                                <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                Profile
                            </a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="login.php" data-toggle="modal" data-target="#logoutModal">
                                <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                Logout
                            </a>
                        </div>
                    </li>

                </ul>

            </nav>
            <!-- End of Topbar -->

            <div class="container-fluid">

                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="n-0 font-weight-bold text-primary">Quizzez</h6>
                    </div>
                    <div class="card-body">

                        <?php
                        if (isset($_SESSION['quiz_success']) && $_SESSION['quiz_success'] != '') {
                            echo '
                            <div class="toast bg-primary text-white" role="alert" aria-live="assertive" aria-atomic="true">
                                <div class="toast-header">
                                    <strong class="mr-auto">Success</strong>
                                    <button type="button" class="ml-2 mb-1 close" data-dismiss="toast" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="toast-body">
                                    ' . $_SESSION['quiz_success'] . '
                                </div>
                            </div>
                            ';
                            unset($_SESSION['quiz_success']);
                        }
                        if (isset($_SESSION['quiz_status']) && $_SESSION['quiz_status'] != '') {
                            echo '
                    <div class="toast bg-danger text-white" role="alert" aria-live="assertive" aria-atomic="true">
                        <div class="toast-header">
                            <strong class="mr-auto">Error</strong>
                            <button type="button" class="ml-2 mb-1 close" data-dismiss="toast" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="toast-body">
                            ' . $_SESSION['quiz_status'] . '
                        </div>
                    </div>
                    ';
                     unset($_SESSION['quiz_status']);
                        }
                        ?>


                        <div class="table-responsive">

                            <?php
                            $connection = mysqli_connect("localhost", "root", "", "admin_quiz");
                            $query = "SELECT * FROM quizzes ";
                            $query_run = mysqli_query($connection, $query);

                            ?>

                            <table class=" table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>Quiz ID</th>
                                        <th>Quiz Name</th>
                                        <th>Quiz Description</th>
                                        <th>Semester</th>
                                        <th>Subject</th>
                                        <th>Created By</th>
                                        <th>Created At</th>
                                        <th>EDIT</th>
                                        <th>DELETE</th>
                                    </tr>
                                </thead>
                                <tbody>

                                    <?php
                                    if (mysqli_num_rows($result_quizzes) > 0) {
                                        while ($row = mysqli_fetch_assoc($result_quizzes)) {
                                    ?>
                                            <tr>
                                                <td><?php echo $row['quiz_id']; ?></td>
                                                <td><?php echo $row['quiz_name']; ?></td>
                                                <td><?php echo $row['quiz_description']; ?></td>
                                                <td><?php echo $row['semester']; ?></td>
                                                <td><?php echo $row['subject']; ?></td>
                                                <td><?php echo $row['created_by']; ?></td>
                                                <td><?php echo $row['created_at']; ?></td>

                                                <td>
                                                    <form action="quizzes_edit.php" method="POST">
                                                        <input type="hidden" name="edit_quiz_id" value="<?php echo $row['quiz_id']; ?>">
                                                        <button type="submit" name="edit_btn" class="btn btn-success">Edit</button>
                                                    </form>
                                                </td>

                                                <td>
                                                    <form action="dquizzes_code.php" method="POST">
                                                        <input type="hidden" name="delete_quiz_id" value="<?php echo $row['quiz_id']; ?>">
                                                        <button type="submit" name="delete_quiz_btn" class="btn btn-danger">Delete</button>
                                                    </form>
                                                </td>
                                            </tr>
                                    <?php
                                        }
                                    }
                                    ?>


                                </tbody>
                            </table>
                        </div>
                    </div>
                    <?php include('includes/scripts.php'); ?>
                    <?php include('includes/footer.php'); ?>



                </div>
            </div>





</body>

</html>