<?php
session_start ();
include('database/quizdbconfig.php');
include('database/dbconfig.php');



// Add the quiz in the database
if (isset($_POST['add_quiz'])) {
    $semester = $_POST['semester'];
    $subject = $_POST['subject'];
    $q_name = $_POST['q_name'];
    $q_description = $_POST['q_description'];
    $created_by = $_POST['created_by'];

    // Insert into SQL table
    $insert_query = mysqli_query($conn, "INSERT INTO `quizzes` (quiz_name, quiz_description, semester, subject, created_by) VALUES ('$q_name', '$q_description', '$semester', '$subject', '$created_by')") or die('Query failed');

   // Check if insertion was successful
if ($insert_query) {
    // Set success message for quiz form
    $_SESSION['quiz_success'] = "Quiz Added Successfully";

    // Redirect to quizform.php
    header("Location: quizform.php");
    exit; // Stop further execution
} else {
    // Set failure message for quiz form
    $_SESSION['quiz_status'] = "Failed to add quiz.";

    // Redirect to quizform.php
    header("Location: quizform.php");
    exit; // Stop further execution
}

}



// Check if the user is logged in and session variable is set
if (isset($_SESSION['username'])) {
    // Connect to the database
    $host = "localhost";
    $dbusername = "root"; // Replace with your actual database username
    $dbpassword = ""; // Replace with your actual database password
    $dbname = "adminpanel"; // Replace with your actual database name
    $conn = new mysqli($host, $dbusername, $dbpassword, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Fetch username from the database based on the logged-in user's session username
    $username = $_SESSION['username'];
    $sql = "SELECT username FROM register WHERE username = '$username'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $username = $row['username']; // Get the username from the database
        }
    }

    // Close the database connection
    $conn->close();
}
?>


   
<!DOCTYPE html>
<html lang="en">

<head>

    <?php
    include('includes/header.php');
    include('includes/navbar.php');
    ?>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Quiz</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        h1 {
            text-align: center;
            margin-top: 20px;
            margin-left: 20px;
        }

        table {

            width: 70%;
            margin-top: 50px;
            margin-left: 200px;
            border-collapse: collapse;
        }

        td,
        th {
            border: 1px solid #ddd;
            padding: 8px;
        }

        td {
            text-align: left;
        }

        label {
            margin-bottom: 5px;
            display: inline-block;
        }

        input[type="text"],
        textarea,
        select {
            width: 95%;
            padding: 8px;
            margin: 5px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button[type="submit"] {
            width: auto;
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            margin: 10px 0;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            float: right;
        }

        button[type="submit"]:hover {
            background-color: #0056b3;
        }

        .form-group {
            margin-bottom: 20px;
        }
    </style>
</head>

<body>
    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <div id="content">
            <!-- Topbar -->
            <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                <!-- Sidebar Toggle (Topbar) -->
                <button id="sidebBar ToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                    <i class="fa fa-bars"></i>
                </button>

                <!-- Text "ADMIN PANEL" -->
                <div class="navbar-brand">
                    <span class="font-weight-bold text-primary">ADMIN PANEL</span>
                </div>

                <!-- Topbar Navbar -->
                <ul class="navbar-nav ml-auto">

                    <!-- Nav Item - User Information -->
                    <li class="nav-item dropdown no-arrow">
                        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo $username; ?></span> <!-- Display the username -->
                            <img class="img-profile rounded-circle" src="img/undraw_profile.svg">
                            <i class="fas fa-caret-down"></i>
                        </a>

                        <!-- Dropdown - User Information -->
                        <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                            <a class="dropdown-item" href="#">
                                <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                Profile
                            </a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="login.php" data-toggle="modal" data-target="#logoutModal">
                                <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                Logout
                            </a>
                        </div>
                    </li>

                </ul>

            </nav>
            <!-- End of Topbar -->
            <h1 style="color: black;">Add Quiz</h1>

            <form action="" method="POST">
                <table>
                    <tr>
                        <td><label for="semester">Semester:</label></td>
                        <td>
                            <select id="semester" name="semester" required>
                                <option value="Semester 1">Semester 1</option>
                                <option value="Semester 2">Semester 2</option>
                                <option value="Semester 3">Semester 3</option>
                                <option value="Semester 4">Semester 4</option>
                                <option value="Semester 5">Semester 5</option>
                                <option value="Semester 6">Semester 6</option>
                                <option value="Semester 7">Semester 7</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td><label for="subject">Subject:</label></td>
                        <td><select id="subject" name="subject" required></select></td>
                    </tr>
                    <tr>
                        <td><label for="quiz_name">Quiz Name:</label></td>
                        <td><input type="text" id="quiz_name" name="q_name" required></td>
                    </tr>
                    <tr>
                        <td><label for="quiz_description">Quiz Description:</label></td>
                        <td><textarea id="quiz_description" name="q_description" rows="4" required></textarea></td>
                    </tr>
                    <tr>
                        <td><label for="created_by">Created By:</label></td>
                        <td><input type="text" id="created_by" name="created_by" required></td>
                    </tr>
                    <tr>
                        <td colspan="2"><button type="submit" name="add_quiz">Add Quiz</button></td>
                    </tr>
                </table>
            </form>

            <script>
                document.getElementById('semester').addEventListener('change', function() {
                    const semester = this.value;
                    const subjectSelect = document.getElementById('subject');

                    // Clear existing options
                    subjectSelect.innerHTML = '';

                    // Add options based on selected semester
                    if (semester === 'Semester 1') {
                        subjectSelect.innerHTML = `
                    <option value="Computer Organization and Architecture">Computer Organization and Architecture</option>
                    <option value="Operating Systems">Operating Systems</option>
                    <option value="General English Proficiency">General English Proficiency</option>
                    <option value="Database Concepts">Database Concepts</option>
                    <option value="Computing Mathematics">Computing Mathematics</option>
                    <option value="Fundamental of Programming">Fundamental of Programming</option>

                `;
                    } else if (semester === 'Semester 2') {
                        subjectSelect.innerHTML = `
                    <option value="Calculus">Calculus</option>
                    <option value="Human Computer Interaction">Human Computer Interaction</option>
                    <option value="Khidmat Masyarakat 1">Khidmat Masyarakat 1</option>
                    <option value="Data Communication Concept">Data Communication Concept</option>
                    <option value="Statistics">Statistics</option>
                    <option value="Object Oriented Programming">Object Oriented Programming</option>


                `;
                    } else if (semester === 'Semester 3') {
                        subjectSelect.innerHTML = `
                    <option value="Data Structures">Data Structures</option>
                    <option value="Study Skills">Study Skills</option>
                    <option value="Entrepreneurship with Digital Applications">Entrepreneurship with Digital Applications</option>
                `;
                    } else if (semester === 'Semester 4') {
                        subjectSelect.innerHTML = `
                        <option value="System Analysis and Design">System Analysis and Design</option>
                    <option value="Express Application Development">Express Application Development</option>
                    <option value="Emerging Technologies">Emerging Technologies</option>
                    <option value="Web Design">Web Design</option>
                    <option value="Computer Network Security">Computer Network Security</option>
                    <option value="Web Application Development">Web Application Development</option>
                    <option value="Introduction to Networks">Introduction to Networks</option>
                    <option value="Networking Essentials">Networking Essentials</option>
                `;
                    } else if (semester === 'Semester 5') {
                        subjectSelect.innerHTML = `
                    <option value="Business Information Management Strategy">Business Information Management Strategy</option>
                    <option value="Enterprise Information Systems">Enterprise Information Systems</option>
                    <option value="Information Technology Essentials">Information Technology Essentials</option>
                    <option value="Linux OS">Linux OS</option>
                    <option value="Intorduction to Mobile Application Development">Intorduction to Mobile Application Development</option>
                    <option value="Computing Projects">Computing Projects</option>
                    
                    
                `;
                    } else if (semester === 'Semester 6') {
                        subjectSelect.innerHTML = `
                    <option value="Leadership and Impersonal Skills 1">Leadership and Impersonal Skills 1</option>
                    <option value="Bahasa Kebangsaan A">Bahasa Kebangsaan A</option>
                    <option value="Pengajian Malaysia 2">Pengajian Malaysia 2</option>
                    <option value="Bahasa Melayu Komunikasi 1">Bahasa Melayu Komunikasi 1</option>
                    <option value="Pengajian Islam 2">Pengajian Islam 2</option>
                    <option value="Etika dan Moral 2">Etika dan Moral 2</option>
                `;
                    } else if (semester === 'Semester 7') {
                        subjectSelect.innerHTML = `
                    <option value="Industrial Training</option>
                    
                `;
                    }

                });
            </script>

</body>
<?php
include('includes/scripts.php');
include('includes/footer.php');
?>

</html>