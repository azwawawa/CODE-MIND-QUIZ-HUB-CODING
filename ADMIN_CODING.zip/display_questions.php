<?php
// Include your database connection file
include('database/quizdbconfig.php');


include('includes/header.php');
include('includes/navbar.php');

// Fetch questions data from the database
$sql_questions = "SELECT * FROM questions";
$result_questions = mysqli_query($conn, $sql_questions);

// Check if query was successful
if (!$result_questions) {
    die("Error fetching questions: " . mysqli_error($conn));
}


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Display Questions</title>
</head>

<body>
    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <div id="content">
            <!-- Topbar -->
            <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                <!-- Sidebar Toggle (Topbar) -->
                <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                    <i class="fa fa-bars"></i>
                </button>

                <!-- Text "ADMIN PANEL" -->
                <div class="navbar-brand">
                    <span class="font-weight-bold text-primary">ADMIN PANEL</span>
                </div>

                 <!-- Topbar Navbar -->
                 <ul class="navbar-nav ml-auto">

<!-- Nav Item - User Information -->
<li class="nav-item dropdown no-arrow">
    <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <span class="mr-2 d-none d-lg-inline text-gray-600 small"></span> <!-- Display the username -->
        <img class="img-profile rounded-circle" src="img/undraw_profile.svg">
        <i class="fas fa-caret-down"></i>
    </a>

    <!-- Dropdown - User Information -->
    <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
        <a class="dropdown-item" href="#">
            <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
            Profile
        </a>
        <div class="dropdown-divider"></div>
        <a class="dropdown-item" href="login.php" data-toggle="modal" data-target="#logoutModal">
            <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
            Logout
        </a>
    </div>
</li>

</ul>

            </nav>
            <!-- End of Topbar -->

            <div class="container-fluid">

                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="n-0 font-weight-bold text-primary">Questions</h6>
                    </div>
                    <div class="card-body">

                        <?php
                        if (isset($_SESSION['success']) && $_SESSION['success'] != '') {

                            echo '<h2 class="bg-primary text-white">' . $_SESSION['success'] . '</h2>';
                            unset($_SESSION['success']);
                        }
                        if (isset($_SESSION['success']) && $_SESSION['status'] != '') {

                            echo '<h2 class="bg-danger">' . $_SESSION['status'] . '</h2>';
                            unset($_SESSION['status']);
                        }

                        ?>

                        <div class="table-responsive">

                            <?php
                            $connection = mysqli_connect("localhost", "root", "", "admin_quiz");
                            $query = "SELECT * FROM questions ";
                            $query_run = mysqli_query($connection, $query);

                            ?>
                            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>Question ID</th>
                                        <th>Quiz ID</th>
                                        <th>Question</th>
                                        <th>Option 1</th>
                                        <th>Option 2</th>
                                        <th>Option 3</th>
                                        <th>Option 4</th>
                                        <th>Correct Answer</th>
                                        <th>Edit</th>
                                        <th>Delete</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    if (mysqli_num_rows($result_questions) > 0) {
                                        while ($row = mysqli_fetch_assoc($result_questions)) {
                                    ?>
                                            <tr>
                                                <td><?php echo $row['question_id']; ?></td>
                                                <td><?php echo $row['quiz_id']; ?></td>
                                                <td><?php echo $row['question']; ?></td>
                                                <td><?php echo $row['option1']; ?></td>
                                                <td><?php echo $row['option2']; ?></td>
                                                <td><?php echo $row['option3']; ?></td>
                                                <td><?php echo $row['option4']; ?></td>
                                                <td><?php echo $row['correct_answer']; ?></td>
                                                <td>
                                                    <form action="question_edit.php" method="POST">
                                                        <input type="hidden" name="edit_question_id" value="<?php echo $row['question_id']; ?>">
                                                        <button type="submit" name="edit_btn" class="btn btn-success">Edit</button>
                                                    </form>
                                                </td>
                                                <td>
                                                    <form action="dquizzes_code.php" method="post">
                                                        <input type="hidden" name="delete_id" value="<?php echo $row['question_id']; ?>">
                                                        <button type="submit" name="delete_question_btn" class="btn btn-danger">Delete</button>
                                                    </form>
                                                </td>
                                            </tr>
                                    <?php
                                        }
                                    }
                                    ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                    <?php include('includes/scripts.php'); ?>
                    <?php include('includes/footer.php'); ?>



                </div>
            </div>





</body>

</html>