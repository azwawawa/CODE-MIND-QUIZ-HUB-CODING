<?php
// Include your database connection file
include 'database/paperdbconfig.php';
include('database/dbconfig.php');
include 'includes/header.php';
include 'includes/navbar.php';

// Fetch quizzes data from the database
$sql_paper = "SELECT * FROM pastpaper";
$result_paper = mysqli_query($conn, $sql_paper);

if (!$result_paper) {
    die("Error fetching papers: " . mysqli_error($conn));
}


?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="sha384-sTJ/hqpFFJb+8A6ND2RuvLqUp/vJsKl+5poafWRyDLciv4Wyw9pQPLs88+RSt2B+" crossorigin="anonymous">

    <title>Display Past Year Paper</title>
</head>

<body>
    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <div id="content">
            <!-- Topbar -->
            <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                <!-- Sidebar Toggle (Topbar) -->
                <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                    <i class="fa fa-bars"></i>
                </button>

                <!-- Text "ADMIN PANEL" -->
                <div class="navbar-brand">
                    <span class="font-weight-bold text-primary">ADMIN PANEL</span>
                </div>

                <!-- Topbar Navbar -->
                <ul class="navbar-nav ml-auto">

                    <!-- Nav Item - User Information -->
                    <li class="nav-item dropdown no-arrow">
                        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span class="mr-2 d-none d-lg-inline text-gray-600 small"></span> <!-- Display the username -->
                            <img class="img-profile rounded-circle" src="img/undraw_profile.svg">
                            <i class="fas fa-caret-down"></i>
                        </a>

                        <!-- Dropdown - User Information -->
                        <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                            <a class="dropdown-item" href="#">
                                <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                Profile
                            </a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="login.php" data-toggle="modal" data-target="#logoutModal">
                                <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                Logout
                            </a>
                        </div>
                    </li>

                </ul>

            </nav>
            <!-- End of Topbar -->

            <div class="container-fluid">
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="n-0 font-weight-bold text-primary">Past Year Papers</h6>
                    </div>
                    <div class="card-body">
                        <?php
                        if (isset($_SESSION['success']) && $_SESSION['success'] != '') {

                            echo '<h2 class="bg-primary text-white">' . $_SESSION['success'] . '</h2>';
                            unset($_SESSION['success']);
                        }
                        if (isset($_SESSION['success']) && $_SESSION['status'] != '') {

                            echo '<h2 class="bg-danger">' . $_SESSION['status'] . '</h2>';
                            unset($_SESSION['status']);
                        }

                        ?>

                        <div class="table-responsive">
                            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>Paper ID</th>
                                        <th>Paper Title</th>
                                        <th>Paper Description</th>
                                        <th>Faculty</th>
                                        <th>Subject</th>
                                        <th>File</th>
                                        <th>Upload Date</th>
                                        <th>Edit</th>
                                        <th>Delete</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    if (mysqli_num_rows($result_paper) > 0) {
                                        while ($row = mysqli_fetch_assoc($result_paper)) {
                                    ?>
                                            <tr>
                                                <td><?= $row['paper_id']; ?></td>
                                                <td><?= $row['paper_title']; ?></td>
                                                <td><?= $row['paper_description']; ?></td>
                                                <td><?= $row['faculty']; ?></td>
                                                <td><?= $row['subject']; ?></td>
                                                <td>
                                                    <?php
                                                    if (!empty($row['file_path'])) {
                                                        $file_path = $row['file_path'];
                                                        $file_name = basename($file_path);
                                                        $file_extension = pathinfo($file_path, PATHINFO_EXTENSION);
                                                        if (in_array($file_extension, ['pdf', 'docx', 'txt'])) {
                                                            echo '<a href="' . $file_path . '" download="' . $file_name . '"><i class="fas fa-download"></i> Download</a>';
                                                        } else {
                                                            echo 'File type not supported';
                                                        }
                                                    } else {
                                                        echo 'No file';
                                                    }
                                                    ?>
                                                </td>
                                                <td><?= $row['upload_date']; ?></td>
                                                <td>
                                                    <form action="paper_edit.php" method="POST">
                                                        <input type="hidden" name="edit_paper_id" value="<?php echo $row['paper_id']; ?>">
                                                        <button type="submit" name="edit_paper_btn" class="btn btn-success">Edit</button>
                                                    </form>
                                                </td>
                                                <td>
                                                    <form action="papercode.php" method="POST">
                                                        <input type="hidden" name="delete_paper_id" value="<?php echo $row['paper_id']; ?>">
                                                        <button type="submit" name="delete_paper_btn" class="btn btn-danger">Delete</button>
                                                    </form>
                                                </td>
                                            </tr>
                                    <?php
                                        }
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <?php include('includes/scripts.php'); ?>
                    <?php include('includes/footer.php'); ?>
                </div>
            </div>
        </div>
    </div>
</body>


</html>