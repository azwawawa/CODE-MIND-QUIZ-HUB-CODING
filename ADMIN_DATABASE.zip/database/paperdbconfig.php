<?php
// Create connection
    
   
    $conn= mysqli_connect('localhost','root','','adminpapers') or die('Connection failed');




?>
