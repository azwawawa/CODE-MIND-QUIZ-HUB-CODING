<?php
// Create connection
    
    $conn= mysqli_connect('localhost','root','','admin_quiz') or die('Connection failed');
   




?>
