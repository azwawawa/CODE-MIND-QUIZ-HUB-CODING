 <!-- Bootstrap core JavaScript-->
 <script src="vendor/jquery/jquery.min.js"></script>
 <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

 <!-- Core plugin JavaScript-->
 <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

 <!-- Custom scripts for all pages-->
 <script src="js/sb-admin-2.min.js"></script>

 <!-- Page level plugins -->
 <script src="vendor/chart.js/Chart.min.js"></script>

 <!-- Page level custom scripts -->
 <script src="js/demo/chart-area-demo.js"></script>
 <script src="js/demo/chart-pie-demo.js"></script>

 <?php

    $connection = mysqli_connect("localhost", "root", "", "adminpanel");
    

    if (isset($_POST['registerbtn'])) {
        $username = $_POST['username'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $cpassword = $_POST['confirmpassword'];

        $email_query = "SELECT * FROM register WHERE email='$email' ";
        $email_query_run = mysqli_query($connection, $email_query);
        if (mysqli_num_rows($email_query_run) > 0) {
            $_SESSION['status'] = "Email Already Taken. Please Try Another one.";
            $_SESSION['status_code'] = "error";
            header('Location: register.php');
        } else {
            if ($password === $cpassword) {
                $query = "INSERT INTO register (username,email,password) VALUES ('$username','$email','$password')";
                $query_run = mysqli_query($connection, $query);

                if ($query_run) {
                    // echo "Saved";
                    $_SESSION['status'] = "Admin Profile Added";
                    $_SESSION['status_code'] = "success";
                    header('Location: register.php');
                } else {
                    $_SESSION['status'] = "Admin Profile Not Added";
                    $_SESSION['status_code'] = "error";
                    header('Location: register.php');
                }
            } else {
                $_SESSION['status'] = "Password and Confirm Password Does Not Match";
                $_SESSION['status_code'] = "warning";
                header('Location: register.php');
            }
        }


        
    }

    
    ?>